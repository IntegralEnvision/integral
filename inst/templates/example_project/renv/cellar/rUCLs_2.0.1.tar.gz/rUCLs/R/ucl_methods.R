#' @importFrom stats qnorm qchisq pnorm qt
#' @export

# ucl_adj_clt_norm --------------------------------------------------------
# Adjusted-Central Limit Theorem UCL
ucl_adj_clt_norm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  n <- length(x)
  mn_x <- mean(x) # added CRS
  sd_x <- sd(x)
  mu_hat_3 <- (n * sum((x - mn_x)^3)) / ((n - 1) * (n - 2))
  khat_3 <- mu_hat_3 / sd_x^3
  z_a <- qnorm(cl)
  z_a_adj <- z_a + (khat_3 * (1 + 2 * z_a^2)) / (6 * sqrt(n))
  ucl <- mn_x + z_a_adj * sd_x / sqrt(n)
  return(ucl)
})


# ucl_adj_gamma_cenkm -----------------------------------------------------
ucl_adj_gamma_cenkm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  n <- length(x)
  smry <- km_ple2(data.frame(x, det))
  khat_km <- as.numeric((smry[1]^2) / (smry[2]))
  mn <- as.numeric(smry[1])

  # Adjusted Beta
  adj.beta <- data.frame(N = c(5, 10, 20, 40, 50), adj.a = c(0.0086, 0.0267, 0.0380, 0.0440, 0.05)) # Table 2-2 ProUCL technical guidence
  if (length(x) >= 50) {
    cl <- 0.95
  } else {
    if (n %in% adj.beta$N) {
      cl <- 1 - adj.beta[adj.beta$N == n, "adj.a"]
    } else {
      x1 <- max(adj.beta$N[adj.beta$N <= length(x)])
      x2 <- min(adj.beta$N[adj.beta$N >= length(x)])
      y1 <- adj.beta[adj.beta$N == x1, "adj.a"]
      y2 <- adj.beta[adj.beta$N == x2, "adj.a"]

      cl <- 1 - ((y1 - y2) / (x1 - x2) * (length(x) - x1) + y1)
    }
  }

  khat_km_bias <- ((n - 3) * khat_km) / n + (2 / (3 * n))
  ucl <- 2 * n * khat_km_bias * mn / qchisq(p = (1 - cl), df = 2 * n * khat_km_bias)
  return(ucl)
})


# ucl_adj_gamma -----------------------------------------------------------

# Adjusted gamma UCL, Beta adjustment table 2-2, ProUCL Technical Guidance version 5.0 using EnvStats
# to alter confidence level input using adjusted alpha for 0.05, when N>= 50 adjusted gamma is the same as the approximate gamma

ucl_adj_gamma <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  adj.beta <- data.frame(
    N = c(5, 10, 20, 40, 50),
    adj.a = c(0.0086, 0.0267, 0.0380, 0.0440, 0.05)
  ) # Table 2-2 ProUCL technical guidence
  if (length(x) >= 50) {
    cl <- 0.95
  } else {
    if (!length(x) %in% adj.beta$N) {
      x1 <- max(adj.beta$N[adj.beta$N <= length(x)])
      x2 <- min(adj.beta$N[adj.beta$N >= length(x)])
      y1 <- adj.beta[adj.beta$N == x1, "adj.a"]
      y2 <- adj.beta[adj.beta$N == x2, "adj.a"]

      cl <- 1 - ((y1 - y2) / (x1 - x2) * (length(x) - x1) + y1)
    } else {
      cl <- 1 - adj.beta[adj.beta$N == length(x), "adj.a"]
    }
  }

  data.set <- EnvStats::egamma(x,
    method = "bcmle", ci = TRUE, ci.type = "upper", ci.method = "chisq.approx",
    conf.level = cl
  )
  ucl <- data.set$interval$limits[["UCL"]]
  names(ucl) <- NULL
  return(ucl)
})

# ucl_approx_gamma --------------------------------------------------------

# GAMMA DISTRIBUTION STATISTICS
# Chi-Squared Approximate gamma UCL, per EnvStats, based on ProUCL Tech Guidance version 4.1.0.
ucl_approx_gamma <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  data.set <- EnvStats::egamma(x,
    method = "bcmle", ci = TRUE,
    ci.type = "upper", ci.method = "chisq.approx", conf.level = cl
  )
  ucl <- data.set$interval$limits[["UCL"]]
  return(ucl)
})


# ucl_approx_gamma_cenkm----------------------------------

# NOTES:
# pu=T indicates that results will match those of Pro-UCL exactly, but are slightly incorrect (based on flawed KM SE calculation).
# .approx is appropriate for sample size (n) greater than or equal to 50
#
# There is a slight difference between this and the ProUCL UCL due to the underlying ChiSq distribution.  ProUCL interpolates
# values from a distribution tables, whereas R is actually calculating the value.

ucl_approx_gamma_cenkm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  n <- length(x)
  smry <- km_ple2(data.frame(x, det))
  khat_km <- as.numeric((smry[1]^2) / (smry[2]))
  khat_km_bias <- ((n - 3) * khat_km) / n + (2 / (3 * n))
  mn <- as.numeric(smry[1])
  ucl <- 2 * n * khat_km_bias * mn / qchisq(p = (1 - cl), df = 2 * n * khat_km_bias)
  return(ucl)
})


# ucl_boot_bca----------------------------------
# BCA Bootstrap UCL
ucl_boot_bca <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  mn_x <- mean(x)
  tns <- nrow(boots)
  mnb <- boots[, 1]
  zhat_0 <- qnorm(length(mnb[mnb < mn_x]) / tns)

  tmp <- replicate(length(x), x)
  diag(tmp) <- NA
  lwo_diff <- mn_x - colMeans(tmp, na.rm = T)

  ahat <- (sum(lwo_diff^3)) / (6 * ((sum(lwo_diff^2))^1.5))

  a2 <- pnorm(zhat_0 + (zhat_0 + qnorm(cl)) / (1 - ahat * (zhat_0 + qnorm(cl))))
  UCL <- (sort(boots[, 1])[ceiling(tns * a2)])
  return(UCL)
})

# ucl_boot_bca_cenkm----------------------------------
ucl_boot_bca_cenkm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  smry <- km_ple2(data.frame(x, det))
  mn_x <- smry[1]
  tns <- nrow(boots)
  mnb <- boots[, 1]
  zhat_0 <- qnorm(length(mnb[mnb < mn_x]) / tns)

  tmp <- replicate(length(x), x)
  tmp_d <- replicate(length(det), det)
  diag(tmp) <- diag(tmp_d) <- NA

  lwo_diff <- sapply(1:length(x), function(i) {
    mn_x - km_ple2(
      data.frame(tmp[, i][!is.na(tmp[, i])], tmp_d[, i][!is.na(tmp_d[, i])])
    )[1]
  })

  ahat <- (sum(lwo_diff^3)) / (6 * (sum(lwo_diff^2))^1.5)
  a2 <- pnorm(zhat_0 + (zhat_0 + qnorm(cl)) / (1 - ahat * (zhat_0 + qnorm(cl))))

  UCL <- (sort(boots[, 1])[ceiling(tns * a2)])
  return(UCL)
})

# ucl_boot_hall------------------------------------------
# 	  ucl.boot.hall
#   Calculates 95% Hall's Bootstrap UCL that adjusts for bias and skewness
#
# Arguments:
# 	x:	A vector of numeric values, including detection limits
# ns: Numberof bootstrap resamples.  2000 is the default in Pro-UCL 5.0
#
# NOTES: ucl.boot.hall.np has the bootstrapping functionally included instead
#        of calling a generic bootstrapping function, because the summary data
#        saved from each bootstrap resample is specialized to Hall's UCL.

ucl_boot_hall <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  a <- 1 - cl
  mn_x <- mean(x)
  sd_x <- sd(x)
  n <- length(x)
  mu_hat_3 <- (n * sum((x - mn_x)^3)) / ((n - 1) * (n - 2))
  khat_3 <- mu_hat_3 / sd_x^3

  Wb <- (boots$mnb - mn_x) / boots$sdb
  Q_W_nm <- Wb + (boots$khat_3b * Wb^2) / 3 + ((boots$khat_3b^2) * (Wb^3)) / 27 + boots$khat_3b / (6 * n)

  tns <- length(Q_W_nm)
  q_a <- sort(Q_W_nm)[ceiling(a * tns)]

  W_q_a <- (1 + khat_3 * (q_a - khat_3 / (6 * n)))
  if (W_q_a < 0) { # invert so cubed root can be taken - R error in cubed root of negative numbers
    W_q_a <- -W_q_a
    W_q_a <- 3 * (-W_q_a^(1 / 3) - 1) / khat_3
  } else {
    W_q_a <- 3 * (W_q_a^(1 / 3) - 1) / khat_3
  }

  UCL <- mn_x - W_q_a * sd_x
  return(UCL)
})




# ucl_boot_perc -----------------------------------------------------------
# Percentile Bootstrap UCL
ucl_boot_perc <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  tns <- nrow(boots)
  UCL <- (sort(boots[, 1])[ceiling(tns * cl)])
  # list(UCL, tns)
  return(UCL)
})

# ucl_boot_perc_cenkm -----------------------------------------------------
ucl_boot_perc_cenkm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  tns <- nrow(boots)
  UCL <- round(sort(boots[, 1])[ceiling(tns * cl)], 4)
  return(UCL)
})

# ucl_boot_t --------------------------------------------------------------
# Bootstrap-t UCL
ucl_boot_t <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  mn_x <- mean(x)
  n <- length(x)
  se_x <- sd(x) / sqrt(n)
  tns <- nrow(boots)
  mnb <- boots[, 1]
  sdb <- boots[, 2]
  tb <- sqrt(n) * ((mnb - mn_x) / sdb)
  t_cl_ns <- sort(tb$mnb)[ceiling(tns * (1 - cl))]
  UCL <- (mn_x - t_cl_ns * se_x)
  return(UCL)
})


# ucl_boot_t_cenkm --------------------------------------------------------
ucl_boot_t_cenkm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  smry <- km_ple2(data.frame(x, det))
  mn_x <- smry[1]
  se_x <- smry[4]
  tns <- nrow(boots)
  mnb <- boots[, 1]
  sdb <- boots[, 2]
  tb <- sqrt(length(det)) * ((mnb - mn_x) / sdb)
  t_cl_ns <- sort(tb)[ceiling(tns * (1 - cl))]
  UCL <- (mn_x - t_cl_ns * se_x)
  return(UCL)
})



# ucl_cheb ----------------------------------------------------------------
# Chebychev UCL calculated using the sample Mean and Sd for given CL
ucl_cheb <- compiler::cmpfun(function(x, det, cl = .95, boots) {
  mn_x <- mean(x)
  n <- length(x)
  se_x <- sd(x) / sqrt(n)
  cf <- sqrt((1 / (1 - cl)) - 1)
  return(mn_x + cf * se_x)
})


# ucl_cheb_99 -------------------------------------------------------------
# Chebychev UCL calculated using the sample Mean and Sd for given CL
ucl_cheb_99 <- compiler::cmpfun(function(x, det, cl = .99, boots) {
  mn_x <- mean(x)
  n <- length(x)
  se_x <- sd(x) / sqrt(n)
  cf <- sqrt((1 / (1 - cl)) - 1)
  ucl <- mn_x + cf * se_x
  names(ucl) <- NULL
  return(ucl)
})



# ucl_cheb_975 ------------------------------------------------------------
# Chebychev UCL calculated using the sample Mean and Sd for given CL
ucl_cheb_97.5 <- compiler::cmpfun(function(x, det, cl = .975, boots) {
  mn_x <- mean(x)
  n <- length(x)
  se_x <- sd(x) / sqrt(n)
  cf <- sqrt((1 / (1 - cl)) - 1)
  ucl <- mn_x + cf * se_x
  names(ucl) <- NULL
  return(ucl)
})

# ucl_cheb_cenkm ----------------------------------------------------------
# 	  ucl.cheb.cenkm
#   Calculates 95% UCL using the KM mean and SE and the Chebyshev factor
#
# Arguments:
# 	x:	A vector of numeric values, including detection limits
# 	det:	A vector of booleans identifying the detection limits in 'data'
#
# ***NOTE: det = T or True if the concentration is ABOVE the detection limit and F or False if it is below the detection limit
#
# NOTE: pu=T indicates that results will match those of Pro-UCL exactly, but are slightly incorrect (based on flawed KM SE calculation).

ucl_cheb_cenkm <- compiler::cmpfun(function(x, det, cl = .95, boots) {
  smry <- km_ple2(data.frame(x, det))
  names(smry) <- NULL
  cf <- sqrt((1 / (1 - cl)) - 1)
  ucl <- smry[1] + cf * smry[4]
  names(ucl) <- NULL
  return(ucl) # HMS removed round
})


# ucl_cheb_cenkm_99 -------------------------------------------------------
# 	  ucl.cheb.cenkm
#   Calculates 95% UCL using the KM mean and SE and the Chebyshev factor
#
# Arguments:
# 	x:	A vector of numeric values, including detection limits
# 	det:	A vector of booleans identifying the detection limits in 'data'
#
# ***NOTE: det = T or True if the concentration is ABOVE the detection limit and F or False if it is below the detection limit
#
# NOTE: pu=T indicates that results will match those of Pro-UCL exactly, but are slightly incorrect (based on flawed KM SE calculation).
ucl_cheb_cenkm_99 <- compiler::cmpfun(function(x, det, cl = .99, boots) {
  smry <- km_ple2(data.frame(x, det))
  cf <- sqrt((1 / (1 - cl)) - 1)
  ucl <- smry[1] + cf * smry[4]
  names(ucl) <- NULL
  return(ucl) # HMS removed round
})

# ucl_cheb_cenkm_975 ------------------------------------------------------
# 	  ucl.cheb.cenkm
#   Calculates 95% UCL using the KM mean and SE and the Chebyshev factor
#
# Arguments:
# 	x:	A vector of numeric values, including detection limits
# 	det:	A vector of booleans identifying the detection limits in 'data'
#
# ***NOTE: det = T or True if the concentration is ABOVE the detection limit and F or False if it is below the detection limit
#
# NOTE: pu=T indicates that results will match those of Pro-UCL exactly, but are slightly incorrect (based on flawed KM SE calculation).
ucl_cheb_cenkm_97.5 <- compiler::cmpfun(function(x, det, cl = .975, boots) {
  smry <- km_ple2(data.frame(x, det))
  cf <- sqrt((1 / (1 - cl)) - 1)
  names(smry) <- NULL
  return((smry[1] + cf * smry[4])) # HMS removed round
})



# ucl_h -------------------------------------------------------------------
# H-UCL
ucl_h <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  n <- length(x)
  m_y <- mean(log(x))
  sd_y <- sd(log(x))
  a <- round(as.numeric((1 - cl)), digits = 2)

  # Determine H-statistic critical value
  H_critval <- rUCLs::H_critval
  h1 <- H_critval[H_critval$a == a & H_critval$n == max(H_critval[H_critval$n <= n, "n"]), ]
  if (n >= 1001) {
    y <- data.frame(
      s_y = h1$s_y,
      a = h1$a,
      test = h1$test,
      n = n,
      crit_val = H_critval[H_critval$a == a & H_critval$n == 1001, "crit_val"]
    )
  } else {
    if (n %in% h1$n) {
      y <- h1
    } else {
      h2 <- H_critval[H_critval$a == a & H_critval$n == min(H_critval[H_critval$n >= n, "n"]), ]

      y <- data.frame(
        s_y = h1$s_y,
        a = h1$a,
        test = h1$test,
        n = n,
        crit_val = ((h1[, "crit_val"] - h2[, "crit_val"]) / (h1[, "n"] - h2[, "n"])) * (n - h1[, "n"]) + h1[, "crit_val"]
      )
    }
  }


  if (sd_y < min(y$s_y)) {
    H_cv <- y[y$s_y == min(y[y$s_y >= sd_y, "s_y"]), "crit_val"]
  }
  if (sd_y > max(y$s_y)) {
    H_cv <- y[y$s_y == max(y[y$s_y <= sd_y, "s_y"]), "crit_val"]
  }
  if (max(y$s_y) > sd_y & sd_y > min(y$s_y) & !sd_y %in% y$s_y) {
    x1 <- max(y[y$s_y <= sd_y, "s_y"])
    x2 <- min(y[y$s_y >= sd_y, "s_y"])
    y1 <- y[y$s_y == x1, "crit_val"]
    y2 <- y[y$s_y == x2, "crit_val"]

    H_cv <- ((y1 - y2) / (x1 - x2) * (sd_y - x1) + y1)
  } else {
    H_cv <- y[y$s_y == sd_y, "crit_val"]
  }
  # UCL
  return(exp(m_y + (sd_y^2) / 2 + (H_cv * sd_y) / (sqrt(n - 1))))
})



# ucl_h_cenkm -------------------------------------------------------------
# H-UCL with Kaplan Meier mean for censored data
ucl_h_cenkm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  n <- length(x)

  smry <- km_ple2(data.frame(log(x), det))
  names(smry) <- NULL
  m_y <- smry[1]
  sd_y <- smry[3]
  a <- round(as.numeric((1 - cl)), digits = 2)

  # Determine H-statistic critical value
  H_critval <- rUCLs::H_critval
  h1 <- H_critval[H_critval$a == a & H_critval$n == max(H_critval[H_critval$n <= n, "n"]), ]
  if (n >= 1001) {
    y <- data.frame(
      s_y = h1$s_y,
      a = h1$a,
      test = h1$test,
      n = n,
      crit_val = H_critval[H_critval$a == a & H_critval$n == 1001, "crit_val"]
    )
  } else {
    if (n %in% h1$n) {
      y <- h1
    } else {
      h2 <- H_critval[H_critval$a == a & H_critval$n == min(H_critval[H_critval$n >= n, "n"]), ]

      y <- data.frame(
        s_y = h1$s_y,
        a = h1$a,
        test = h1$test,
        n = n,
        crit_val = ((h1[, "crit_val"] - h2[, "crit_val"]) / (h1[, "n"] - h2[, "n"])) * (n - h1[, "n"]) + h1[, "crit_val"]
      )
    }
  }


  if (sd_y < min(y$s_y)) {
    H_cv <- y[y$s_y == min(y[y$s_y >= sd_y, "s_y"]), "crit_val"]
  }
  if (sd_y > max(y$s_y)) {
    H_cv <- y[y$s_y == max(y[y$s_y <= sd_y, "s_y"]), "crit_val"]
  }
  if (max(y$s_y) > sd_y & sd_y > min(y$s_y) & !sd_y %in% y$s_y) {
    x1 <- max(y[y$s_y <= sd_y, "s_y"])
    x2 <- min(y[y$s_y >= sd_y, "s_y"])
    y1 <- y[y$s_y == x1, "crit_val"]
    y2 <- y[y$s_y == x2, "crit_val"]

    H_cv <- ((y1 - y2) / (x1 - x2) * (sd_y - x1) + y1)
  } else {
    H_cv <- y[y$s_y == sd_y, "crit_val"]
  }
  # UCL
  ucl <- exp(m_y + (sd_y^2) / 2 + (H_cv * sd_y) / (sqrt(n - 1)))
  return(ucl)
})


# ucl_t -------------------------------------------------------------------
# Student's t UCL
ucl_t <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  mn_x <- mean(x)
  n <- length(x)
  vr_x <- var(x)
  return(mn_x + qt(p = cl, df = n - 1) * sqrt(vr_x / n))
})

# ucl_t_cenkm -------------------------------------------------------------------
# 	  ucl.t.cenkm
#   Calculates 95% UCL using the KM mean and SE and the student's t distribution
#
# Arguments:
# 	x:	A vector of numeric values, including detection limits
# 	det:	A vector of booleans identifying the detection limits in 'data'
#
# ***NOTE: det = T or True if the concentration is ABOVE the detection limit and F or False if it is below the detection limit


# Kaplan-Meier Student's t UCL
ucl_t_cenkm <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  smry <- km_ple2(data.frame(x, det))
  ucl <- (smry[1] + qt(p = cl, df = length(x) - 1) * smry[4])
  names(ucl) <- NULL
  return(ucl)
})



# ucl_max -----------------------------------------------------------------
# maximum concentration
ucl_max <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  d <- data.frame(x, det)
  return(max(d[d$det == TRUE, "x"]))
})


# ucl_modt ----------------------------------------------------------------
ucl_modt <- compiler::cmpfun(function(x, det, cl = 0.95, boots) {
  mn_x <- mean(x)
  n <- length(x)
  vr_x <- var(x)
  mu_hat_3 <- (n * sum((x - mn_x)^3)) / ((n - 1) * (n - 2))
  return(mn_x + mu_hat_3 / (6 * vr_x * n) + qt(p = cl, df = n - 1) * sqrt(vr_x / n))
})


# call_ucl_method ---------------------------------------------------------
# wrapper function to call ucl method by method name and return ucl, should not break if an individual ucl method breaks

# example inputs:
# method = "ucl_t_cenkm"
# boots = NA
# x = head(d_example$concentration, obv_num)
# det = head(d_example$detected, obv_num)

call_ucl_method <- function(method, x, det, boots) {
  if (length(x) == length(det) & is.numeric(x)) {
    cl <- ifelse(grepl("cheb", method) & grepl("*[[:digit:]]", method),
      as.numeric(stringr::str_extract(method, "\\d\\d\\.\\d|\\d\\d")) / 100,
      0.95
    )
    args <- list(x, det, cl, boots)
    try(ucl_in <- rlang::exec(method, !!!args), silent = T)
    if (exists("ucl_in")) {
      names(ucl_in) <- NULL
      return(ucl_in)
    } else {
      return(NA)
    }
  } else {
    return(NA)
  }
}
