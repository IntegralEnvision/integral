#' @export

figure_template <- function (orient = "L", doc.title="Document Title",  
                             fig.title="Descriptive Figure Title", fig.num="X", notes="") {

  if (orient=="L") {
  
    #Page Border 
    grid::grid.rect(x=0, y=0, height=1, width=1, just=c('left', 'bottom'), draw=T)
    
    #Notes Box and Text
    grid::grid.rect(x=0, y=0, height=0.138, width=0.525, just=c('left', 'bottom'), draw=T)
    notes <- sapply(lapply(notes, strwrap, 70), paste, collapse = "\n")
    grid::grid.text(paste("Notes: ", "\n", notes, sep=""), x=0.0125, y=0.1163, just=c('left', 'top'), 
              gp=grid::gpar(fontsize=8))
    grid::grid.text("DRAFT", x=0.5125, y=0.017, just=c("right", "bottom"), 
              gp=grid::gpar(fontsize=16, col='red',fontface='bold'))
    
    #Document Title Box and Text
    grid::grid.rect(x=.525, y=0, height=0.069, width=0.475, just=c('left', 'bottom'), draw=T)
    if (nchar(doc.title)>50) {warning(paste("Document title too long - Figure ", fig.num, sep=""))}
    grid::grid.text(paste0(doc.title), x=0.538, y=0.06, just=c('left', 'top'), gp=grid::gpar(fontsize=8))
    
    #Figure Number Box and Text
    grid::grid.rect(x=0.9, y=0.069, height=0.069, width=0.1, just=c('left', 'top'), draw=T)
    
    grid::grid.text("Figure", x=0.95, y=0.035, just=c('center','bottom'), gp=grid::gpar(fontsize=10))
    grid::grid.text(fig.num, x=0.95, y=0.025, just=c('center','top'), gp=grid::gpar(fontsize=10, fontface='bold'))
    
    #Descriptive Title Box and Text
    grid::grid.rect(x=.525, y=.069, height=0.069, width=0.475, just=c('left', 'bottom'), draw=T)
    
    if (nchar(fig.title) < 60) {
      grid::grid.text(fig.title, x=0.538, y=0.104, just=c('left', 'top'), gp=grid::gpar(fontsize=9, 
                                                                           fontface='bold'))
    } else {
      fig.title <- sapply(lapply(fig.title, strwrap, 60), paste, collapse = "\n")
      grid::grid.text(fig.title, x=0.538, y=0.13, just=c('left', 'top'), gp=grid::gpar(fontsize=8, 
                                        fontface='bold'))
      if (nchar(fig.title)>120) {warning(paste("Descriptive Figure title too long - Figure ", 
                                               fig.num, sep=""))}
    }
  
  } else {
    
    ##Template for portrait orientation
    
    #Page Border 
    grid::grid.rect(x=0, y=0, height=1, width=1, just=c('left', 'bottom'), draw=T)
    
    #Notes Box and Text
    grid::grid.rect(x=0, y=0, height=0.1, width=0.345, just=c('left', 'bottom'), draw=T)
    notes <- sapply(lapply(notes, strwrap, 60), paste, collapse = "\n")
    grid::grid.text(paste("Notes: ", "\n", notes, sep=""), x=0.017, y=0.083, just=c('left', 'top'), 
              gp=grid::gpar(fontsize=8))
    grid::grid.text("DRAFT", x=0.328, y=0.017, just=c("right", "bottom"), 
              gp=grid::gpar(fontsize=16, col='red',fontface='bold'))
    
    #Document Title Box and Text
    grid::grid.rect(x=.345, y=0, height=0.05, width=0.862, just=c('left', 'bottom'), draw=T)
    if (nchar(doc.title)>100) {warning(paste("Document title too long - Figure ", fig.num, sep=""))}
    grid::grid.text(paste(doc.title,sep=""), x=0.362, y=0.045, just=c('left', 'top'), gp=grid::gpar(fontsize=8))
    
    #Figure Number Box and Text
    grid::grid.rect(x=0.862, y=0.05, height=0.05, width=0.138, just=c('left', 'top'), draw=T)
  
    grid::grid.text("Figure", x=0.931, y=0.038, just=c('center','bottom'), gp=grid::gpar(fontsize=10))
    grid::grid.text(fig.num, x=0.931, y=0.028, just=c('center','top'), gp=grid::gpar(fontsize=10, fontface='bold'))
  
    #Descriptive Title Box and Text
    grid::grid.rect(x=.345, y=.05, height=0.05, width=0.655, just=c('left', 'bottom'), draw=T)
    
    if (nchar(fig.title) < 60) {
      grid::grid.text(fig.title, x=0.362, y=0.08, just=c('left', 'top'), gp=grid::gpar(fontsize=9, 
                                                                            fontface='bold'))
    } else {
      fig.title <- sapply(lapply(fig.title, strwrap, 60), paste, collapse = "\n")
      grid::grid.text(fig.title, x=0.362, y=0.085, just=c('left', 'top'), gp=grid::gpar(fontsize=8, 
                                                                             fontface='bold'))
      if (nchar(fig.title)>120) {warning(paste("Descriptive Figure title too long - Figure ", 
                                               fig.num, sep=""))}
    }
    
  } #End of L / P switch

} #End function
