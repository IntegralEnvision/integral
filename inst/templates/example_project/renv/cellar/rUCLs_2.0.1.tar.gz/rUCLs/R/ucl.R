#' @export


# UCL Implementation script
ucl <- function(x,
                det,
                quals = NA,
                gof = NA, # for backwards compat
                boot = TRUE, # or FALSE
                max.sub = TRUE, # or FALSE
                method = "Select", # or "Custom", "All", "Compare"
                method.custom = NA, # needs input for Custom of Compare
                ns = 1000) {
  # Message to user that gof input will not be used ----
  if (length(gof) > 1 & !is.na(gof[1])) {
    message("GOF statistics will be recalculated to ensure compatibility with ucl calculations. No need for user input for GOF.")
  }

  # Check data input types -----
  assertthat::assert_that(
    length(x) == length(det),
    is.numeric(c(x)),
    is.logical(c(boot, max.sub, det))
  )

  # Get gof output ----
  gof <- suppressWarnings(proucl_gof(x, det, quals, include_nd = F))

  ucl_all <- c(
    "ucl_max", "ucl_t", "ucl_modt", "ucl_adj_clt_norm",
    "ucl_h", "ucl_cheb", "ucl_cheb_97.5", "ucl_cheb_99", "ucl_boot_t",
    "ucl_boot_perc", "ucl_boot_hall", "ucl_boot_bca",
    "ucl_approx_gamma", "ucl_adj_gamma", "ucl_t_cenkm",
    "ucl_boot_t_cenkm", "ucl_boot_perc_cenkm",
    "ucl_boot_bca_cenkm", "ucl_approx_gamma_cenkm",
    "ucl_adj_gamma_cenkm", "ucl_h_cenkm",
    "ucl_cheb_cenkm", "ucl_cheb_cenkm_97.5",
    "ucl_cheb_cenkm_99"
  )

  # Check that method and method.custom match appropriately ------
  if (method == "Custom") { # Custom method input check
    if (length(method.custom) != 1 | !all(method.custom %in% ucl_all)) {
      stop("METHOD ERROR: Custom method must have exactly 1 appropriate method.custom argument.")
    }
    if (grepl("boot", method.custom) & boot != TRUE) {
      stop("METHOD ERROR: Custom method requires bootstrapping, change bootstrap input.")
    }
  }
  if (method == "Compare" &
    !all(method.custom %in% ucl_all)) { # Custom method input check
    stop("METHOD ERROR: Compare method must have at least 1 appropriate method.custom argument.")
  }

  # ________________________________________________-
  # ProUCL Selected UCL method -----

  sum_stat <- gof$SummaryStats
  ifelse((grepl("approximate", gof$Distribution$Selected) &
    (grepl("gamma", gof$Distribution$Selected) |
      grepl("lognormal", gof$Distribution$Selected))),
  dist_select <- gsub("approximate ", "", gof$Distribution$Selected),
  dist_select <- gof$Distribution$Selected
  )
  # Select appropriate UCL methods -----
  if (method %in% c("All", "Select", "Compare") &
    sum_stat$n_detect > 0) { # All #Select #Compare
    ProUCL <- rUCLs::ProUCL
    #ProUCL <- read.csv("data/rUCL_hierarchy.csv")

    # Select all appropriate UCL methods based on ProUCL version 5.1
    sucl_all <- ProUCL[
      sum_stat$n >= ProUCL$N_min &
        sum_stat$n < ProUCL$N_max &
        (sum_stat$fod < 1) == ProUCL$Censored &
        sum_stat$fod >= ProUCL$FOD_min &
        sum_stat$fod < ProUCL$FOD_max &
        dist_select == ProUCL$Distribution &
        sum_stat$n_detect >= ProUCL$N_D_min &
        sum_stat$n_detect < ProUCL$N_D_max &
        sum_stat$n_detect_unique >= ProUCL$N_uniqueD_min &
        sum_stat$n_detect_unique < ProUCL$N_uniqueD_max &
        sum_stat$sigma >= ProUCL$sigma_min &
        sum_stat$sigma < ProUCL$sigma_max &
        gof$Fits$gamfit[["estimate"]][["shape"]] <= ProUCL$k_max &
        gof$Fits$gamfit[["estimate"]][["shape"]] > ProUCL$k_min,
      c(
        "ucl_method", "ucl_method_name2",
        "ucl_ci", "ucl_warning", "ucl_code", "Preference"
      )
    ]

    # Select preferred method
    sucl <- sucl_all[
      sucl_all$Preference == 1,
      c(
        "ucl_method", "ucl_method_name2",
        "ucl_ci", "ucl_warning", "ucl_code"
      )
    ]

    # Get list of alternative ucl_methods that are not first preferences
    alt_sucls <- sucl_all[sucl_all$Preference != 1, c("ucl_method")]

    ucl_select <- data.frame(
      ucl_select_method = sucl$ucl_method_name2,
      ucl_select_value = NA,
      ucl_warning = sucl$ucl_warning,
      ucl_code = sucl$ucl_code
    )

    ucl_select_method <- sucl$ucl_method
  }
  if (method == "Custom" & sum_stat$n_detect > 0) { # "Custom"
    ProUCL <- rUCLs::ProUCL
    sucl <- unique(ProUCL[
      ProUCL$ucl_method == method.custom,
      c(
        "ucl_method", "ucl_method_name2",
        "ucl_ci", "ucl_warning", "ucl_code"
      )
    ])
    ucl_select <- data.frame(
      ucl_select_method = sucl$ucl_method_name2,
      ucl_select_value = NA,
      ucl_warning = sucl$ucl_warning,
      ucl_code = sucl$ucl_code
    )

    ucl_select_method <- sucl$ucl_method
  }
  if (sum_stat$n_detect == 0) { # all non detects
    ucl_select <- data.frame(
      ucl_select_method = "Not Detected",
      ucl_select_value = NA,
      ucl_warning = "Not detected.",
      ucl_code = "F2"
    )

    ucl_select_method <- NA
  }

  # ________________________________________________
  ## All non-detects scenario ----
  if (sum_stat$n_detect == 0) {
    out <- t(data.frame(value = rep(NA, length(ucl_all))))
    colnames(out) <- ucl_all
  } else {
    # ________________________________________________
    ## All detects scenario -----
    if (length(unique(det)) == 1 & sum_stat$n_detect >= 4) { # >=4 all detects
      if (method %in% c("Custom", "Compare") &
        TRUE %in% (grepl("cen", method.custom))) { # Custom Compare method check
        stop("METHOD ERROR: Data are all detected.
               Select method(s) without censoring.")
      }
      if (method == "All") { # "All" method
        ucl_names <- grep("cen", ucl_all, value = T, invert = T)
      }
      if (method == "Compare") { # "Compare" method
        ucl_names <- method.custom
      }
      if (method == "Select" | method == "Custom") { # "Select or Custom method"
        ucl_names <- ucl_select_method
      }
      if (boot == FALSE & grepl("boot", ucl_select_method)) {
        ucl_names <- c(
          grep("boot", ucl_names, invert = T, value = T),
          ucl_select_method
        )
      }
      if (boot == FALSE & !grepl("boot", ucl_select_method)) {
        ucl_names <- grep("boot", ucl_names, invert = T, value = T)
      }
      if (TRUE %in% grepl("boot", ucl_names)) {
        boots <- boot_ucl(x, ns)
      } else {
        boots <- NA
      }
    } # if all detected
    # ________________________________________________
    ## Mixed detects and non-detects scenario ----
    if (length(unique(det)) > 1 & sum_stat$n_detect >= 4) { # >=4 mixed detects
      if (method %in% c("Custom", "Compare") &
        FALSE %in% (grepl("cen", method.custom))) { # Custom Compare method check
        stop("METHOD ERROR: Data contain nondetects.
               Select method(s) with censoring.")
      }
      if (method == "All") { # "All" method
        ucl_names <- grep("cen", ucl_all, value = T)
      }
      if (method == "Compare") { # "Compare" method
        ucl_names <- method.custom
      }
      if (method %in% c("Select", "Custom")) { # "Select or Custom method"
        ucl_names <- ucl_select_method
      }
      if (boot == FALSE & grepl("boot", ucl_select_method)) {
        ucl_names <- c(grep("boot", ucl_names, invert = T, value = T), ucl_select_method)
      }
      if (boot == FALSE & !grepl("boot", ucl_select_method)) {
        ucl_names <- grep("boot", ucl_names, invert = T, value = T)
      }
      if (TRUE %in% grepl("boot", ucl_names)) {
        boots <- boot_km_2(x, det, ns)
      } else {
        boots <- NA
      }
    } # if mix
    # ________________________________________________
    ## Less than 4 detected values scenario -----
    if (method %in% c("Custom", "Compare") &
      (sum_stat$n_detect < 4) &
      FALSE %in% (grepl("ucl_max", method.custom))) { # Custom Compare method check
      stop("METHOD ERROR: Data contain less than 4 detects
                 Only ucl_max method appropriate.")
    }
    if (sum_stat$n_detect < 4) {
      ucl_names <- "ucl_max"
      boots <- NA
    } # if N<4

    # ________________________________________________
    ## If bootstrapping cannot be done due to sample size ----
    if (is.character(boots) & "All" %in% method) {
      ucl_names <- grep("boot", ucl_names, value = T, invert = T)
    }
    if (is.character(boots) & !("All" %in% method)) {
      stop(paste0("BOOTSTRAPPING ERROR: ", boots, " Select alternative method."))
    }


    # Perform ucl methods chosen ----
    out <- t(data.frame(values = sapply(
      ucl_names,
      function(meth) {
        call_ucl_method(meth, x, det, boots)
      }
    )))

    # Clean up ucl output----
    # NAs for UCL methods not used
    outna <- t(data.frame(value = rep(
      NA, length(ucl_all[!ucl_all %in% colnames(out)])
    )))
    colnames(outna) <- ucl_all[!ucl_all %in% colnames(out)]

    ## Final Output -----
    out <- cbind(out, outna)
    colnames(out) <- sapply(colnames(out), function(x) {
      ifelse(grepl("[[:digit:]]", x), x, paste0(x, "_95"))
    })
    out <- as.data.frame(out)
    row.names(out) <- NULL

    out[, sapply(ucl_all, function(x) {
      ifelse(grepl("[[:digit:]]", x), x, paste0(x, "_95"))
    }, USE.NAMES = F)]
    # ________________________________________________-
  } # if ND
  # ________________________________________________-
  # Final data output mods ----
  sum_stat <- cbind(sum_stat, gof$GOF_Stat)
  out <- cbind(sum_stat, out)
  if (sum_stat$n_detect > 0 &
    method %in% c("All", "Select", "Custom")) { # get UCL select values
    ucl_select$ucl_select_value <- out[, sapply(ucl_select_method, function(x) {
      ifelse(grepl("[[:digit:]]", x), x, paste0(x, "_95"))
    }, USE.NAMES = F)]
    out <- cbind(out, ucl_select)
  }
  if (method %in% c("Select", "Custom")) { # method == "Select" or "Custom"
    out <- cbind(out, ucl_select)
    out <- out[, c(names(sum_stat), names(ucl_select))]
    ## Add column for alternate ucls that are appropriate ----
  }
  if (method == "Select" & exists("alt_ucls")) {
    out$alt_ucls <- ifelse(length(alt_sucls) > 0,
      paste(alt_sucls, sep = ", "),
      NA
    )
  }
  if (method == "Select" & !exists("alt_ucls")) {
    out$alt_ucls <- NA
  }

  if (method != "Compare" & out$n_detect >0) { 
    # Create selected EPC field ----
    # if max sub is selected, the EPC value will be the max detected value when the ucl is > max_d
    out$epc <- out$ucl_select_value
    if (max.sub == TRUE) {
      ifelse(out$max_d < out$ucl_select_value,
        out$epc <- out$max_d,
        out$epc <- out$epc
      )
      if (out$max_d < out$ucl_select_value & out$n_detect > 0) {
        out$ucl_warning <- paste0(
          out$ucl_warning,
          " The 95 UCL is greater than the maximum detected value; therefore the maximum detected value is selected as the EPC."
        )
        out$ucl_code <- paste0(out$ucl_code, " F3")
      }
    }

    # Assign UCL codes/warnings ----
    if(out$n_detect >0){
    if (!grepl("F3", out$ucl_code) & !
    grepl("F2", out$ucl_code) & !
    grepl("F4", out$ucl_code)) {
      out$ucl_code <- paste0(out$ucl_code, " F1")
      out$ucl_warning <- paste0(
        out$ucl_warning,
        " The 95 UCL is selected as the EPC."
      )
    }

    out$ucl_code <- gsub("^\\s", "", out$ucl_code)
    out$ucl_warning <- gsub("^\\s", "", out$ucl_warning)

    out$ucl_code <- paste(factor(strsplit(out$ucl_code, " ")[[1]],
      levels = c("F1", "F2", "F3", "F4", "F5", "F6", "F7"),
      ordered = T
    )[order(factor(strsplit(out$ucl_code, " ")[[1]],
      levels = c("F1", "F2", "F3", "F4", "F5", "F6", "F7"),
      ordered = T
    ))],
    collapse = " "
    )}

    # Additional warnings -------
    add_warning <- c()

    ## If only one unique detect ----
    if (sum_stat$n_unique == 1) {
      add_warning <- c(
        add_warning,
        "Only 1 distinct value - should  not use r/ProUCL."
      )
    }

    ## If ProUCL may have picked normal when rUCL chose lognormal ----
    if ((0.04 < sum_stat$S_W_p_value_Normal &
      sum_stat$S_W_p_value_Normal < 0.05) &
      (0.04 < sum_stat$Lilliefors_p_value_Normal &
        sum_stat$Lilliefors_p_value_Normal < 0.05) &
      (sum_stat$dist_select == "lognormal")) {
      add_warning <- c(
        add_warning,
        "Possible discrepancy on distribution choice compared to ProUCL."
      )
    }

    ## If rUCL chose lognormal while ProUCL would have defaulted to gamma----
    if (grepl("gamma", sum_stat$dist_all) &
      grepl("lognormal", sum_stat$dist_all) &
      sum_stat$dist_select == "lognormal") {
      add_warning <- c(
        add_warning,
        "UCL is based on a best fit lognormal which may differ than ProUCL."
      )
    }

    ## If KM calculation is different because of a high ND bias -----
    d <- data.frame(x, det)
    if ((d$det[d$x == min(d$x)][1] == F) &
        exists("sucl")) {
      if(grepl("cen", sucl$ucl_method)) {
        add_warning <- c(
        add_warning,
        "High nondetect bias may result in different ucl than ProUCL based on KM calculation."
      )
    }}

    ## If adjusted gamma distribution was selected -----
    # TODO: check the bias direction
    if (exists("sucl")){
    if (grepl("ucl_adj_gamma", sucl$ucl_method)) {
      add_warning <- c(
        add_warning,
        "UCL may be biased HIGHER compared to ProUL due to adjusted gamma calculation."
      )
    }}

    ## If H-statistic was used -----
    # TODO: check the bias direction
    if (exists("sucl")){
    if (grepl("ucl_h", sucl$ucl_method)) {
      add_warning <- c(
        add_warning,
        "UCL may be biased HIGHER compared to ProUL due to H statistic calculation."
      )
    }}

    # Combine all warnings
    out$ucl_warning <- paste0(c(out$ucl_warning, add_warning), collapse = " ")
  }
  return(out)
} # function
