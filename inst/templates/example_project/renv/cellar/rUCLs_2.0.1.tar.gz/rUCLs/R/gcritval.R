#' @export
# Calculate gamma critical value

gcritval <- function(pval, test, shape, n) {
  gval <- rUCLs::gval
  if (shape < min(gval$shape) | shape > max(gval$shape)) {
    ifelse(shape < min(gval$shape), shape <- min(gval$shape), shape)
    ifelse(shape > max(gval$shape), shape <- max(gval$shape), shape)

    g2 <- gval[gval$test == test & gval$p == pval &
      gval$shape == max(gval[gval$shape <= shape, "shape"]), ]
  } else {
    # interpolate shape
    g1 <- gval[gval$test == test & gval$p == pval &
      (gval$shape == max(gval[gval$shape <= shape, "shape"]) |
        gval$shape == min(gval[gval$shape >= shape, "shape"])), ]

    x1 <- max(g1[g1$shape <= shape, "shape"])
    x2 <- min(g1[g1$shape >= shape, "shape"])
    y1 <- g1[g1$shape == x1, ]
    y2 <- g1[g1$shape == x2, ]


    g2 <- data.frame(
      n = y1$n, test = y1$test, pval = y1$p, shape = rep(shape, nrow(y1)),
      crit_val = ((y1$crit_val - y2$crit_val) / (x1 - x2) * (shape - x2)) + y2$crit_val
    )
  }
  if (n < min(g2$n) | n > max(g2$n) | n %in% g2$n) {
    ifelse(n < min(g2$n), n <- min(g2$n), n)
    ifelse(n > max(g2$n), n <- max(g2$n), n)

    g2[g2$n == max(g2[g2$n <= n, "n"]), "crit_val"]
  } else {
    # Interpolate n
    x1 <- max(g2[g2$n <= n, "n"])
    x2 <- min(g2[g2$n >= n, "n"])
    y1 <- g2[g2$n == x1, "crit_val"]
    y2 <- g2[g2$n == x2, "crit_val"]

    (y1 - y2) / (x1 - x2) * (n - x2) + y2
  }
}
