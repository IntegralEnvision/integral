#' @importFrom stats ppoints
#' @export


qqcomp2 <- function(ft, xlim, ylim, xlogscale = FALSE, ylogscale = FALSE,
                    main, xlab, ylab, fitpch, fitcol, addlegend = TRUE, legendtext,
                    xlegend = "bottomright", ylegend = NULL, use.ppoints = TRUE,
                    a.ppoints = 0.5, line01 = TRUE, line01col = "black", line01lty = 1,
                    ynoise = TRUE, ...) {
  if (inherits(ft, "fitdist")) {
    ft <- list(ft)
  }
  else if (!is.list(ft)) {
    stop("argument ft must be a list of 'fitdist' objects")
  }
  else {
    if (any(sapply(ft, function(x) !inherits(x, "fitdist")))) {
      stop("argument ft must be a list of 'fitdist' objects")
    }
  }
  if (!is.null(ft[[1]]$weights)) {
    stop("qqcomp is not yet available when using weights")
  }
  nft <- length(ft)
  if (missing(fitcol)) {
    fitcol <- 2:(nft + 1)
  }
  if (missing(fitpch)) {
    fitpch <- rep(21, nft)
  }
  fitcol <- rep(fitcol, length.out = nft)
  fitpch <- rep(fitpch, length.out = nft)
  if (missing(xlab)) {
    xlab <- "Theoretical quantiles"
  }
  if (missing(ylab)) {
    ylab <- "Empirical quantiles"
  }
  if (missing(main)) {
    main <- "Q-Q plot"
  }
  mydata <- ft[[1]]$data
  verif.ftidata <- function(fti) {
    if (any(fti$data != mydata)) {
      stop("All compared fits must have been obtained with the same dataset")
    }
    invisible()
  }
  lapply(ft, verif.ftidata)
  n <- length(mydata)
  sdata <- sort(mydata)
  if (use.ppoints) {
    obsp <- ppoints(n, a = a.ppoints)
  } else {
    obsp <- (1:n) / n
  }
  largedata <- (n > 10000)
  comput.fti <- function(i, ...) {
    fti <- ft[[i]]
    para <- c(as.list(fti$estimate), as.list(fti$fix.arg))
    distname <- fti$distname
    qdistname <- paste("q", distname, sep = "")
    do.call(qdistname, c(list(p = obsp), as.list(para)))
  }
  fittedquant <- sapply(1:nft, comput.fti, ...)


  list(fitestimates = fittedquant)
}
