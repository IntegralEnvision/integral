#' @importFrom stats sd shapiro.test reshape
#' @export


# ===============================================================================
#                       2015, Integral Consulting Inc.                         #
# ===============================================================================
# ===============================================================================
#  ProUCL_GOF.r
# ===============================================================================
# PURPOSE:
#   Goodness of fit for normal, lognormal and gamma distributions for data
#   with and without detects.
#
# NOTES:
#   1) Based on ProUCL 5.0 technical guidance.
#
# PROJECT INFORMATION:
#   Name: BCSA
#   Number: C1030-2001D
#
# HISTORY:
#   Date		        Remarks
# 	-----------	   ---------------------------------------------------------------
# 	 12/15/2015     Goodness of fit test script for UCL
#  12/17/2015     P. Pooler-Eisenbies QAs Script
#  12/18/2015     H. Summers updates with notes from QA and to add normal approximate cavet.
#  05/02/2016     H. Summers adjusts normal distribution test so that data are normal if either
#                 SW or Lillifores says normal, also upped sd(log(x)) requirement for normal to 1.0 to match ProUCL output.
#  11/16/2021     K. Heal added error handling at start, incorporating updated km calc for
# ===============================================================================

# ===============================================================================
# GOODNESS OF FIT TESTING
# ===============================================================================
# quals=NA
# include_nd=FALSE
# pval_norm=.05
# pval_lnnorm=.05
# pval_gamma=0.05


proucl_gof <- function(x, det, quals = NA, include_nd = FALSE,
                       pval_norm = .05, pval_lnnorm = .05, pval_gamma = 0.05) {
  assertthat::assert_that(length(x) == length(det))
  assertthat::assert_that(is.numeric(c(x, pval_norm, pval_lnnorm, pval_gamma)))
  assertthat::assert_that(is.logical(c(det, include_nd)))
  assertthat::assert_that(length(x) > 0)

  # setup dataframe of values, detection, quals
  d1 <- data.frame(x = x, det = det, quals = quals)
  d1 <- d1[order(d1$x), ]

  # calculate frequency of detection and number of detects
  fod <- nrow(d1[d1$det == TRUE, ]) / nrow(d1)
  n_detect <- nrow(d1[d1$det == TRUE, ])

  if (fod < 1 & include_nd == TRUE & fod >= 0.2 & n_detect >= 4) # If any of the data are non-detect and include_nd==TRUE, then perform the following data substitutions to assess distribution.
    {
      # ROS method when input data includes ND only used when FOD>= 20% or there are at least 4 detects
      data <- suppressWarnings(NADA::cenros(d1$x, !d1$det))
      d.ROS <- data.frame(x = data$modeled, det = !(data$censored))
      d.ROS <- d.ROS[order(d.ROS$x), ]
      x <- d.ROS$x
      det <- d.ROS$det
      fit_type <- "ROS Imputed Non-detects"
    } else {
    x <- d1[d1$det == TRUE, "x"]
    det <- d1[d1$det == TRUE, "det"]
    fit_type <- "Detects Only"
  }

  #------------------------------------------------------------------
  # Summary Statistics
  #------------------------------------------------------------------

  n <- nrow(d1)
  n_unique <- length(unique(d1$x))

  if (fod > 0) {
    d1_det <- d1[d1$det == TRUE, ]
    n_detect_unique <- length(unique(d1_det[, "x"]))
    min_d <- min(d1_det[, "x"])
    min_d_qual <- d1_det[which.min(d1_det[, "x"]), "quals"]
    max_d <- max(d1_det[, "x"])
    max_d_qual <- d1_det[which.max(d1_det[, "x"]), "quals"]
    mean_d <- mean(d1_det[, "x"])
    sd_d <- sd(d1_det[, "x"])
    ifelse(n_detect < 2, sigma <- 0, sigma <- sd(log(d1_det[, "x"])))

    if (fod < 1 & n_detect_unique >= 2) { # QA - changed this from >4 to n_detect_unique>=2 - updates to KM now allow for any # of distinct values however need to add warning in UCL "Only one distinct value was detected. UCL calculation should not be performed on this dataset. Suggest using alternative site-specific values determined by the Project Team to estimate environmental parameters.")
      # km <- km_ple2(d1$x,d1$det)
      km <- km_ple2(d1[, c("x", "det")]) # QA - Update to non-dev named code when QA is complete
      mean_km <- km[1]
      sd_km <- km[2]
      mean_type <- "Kaplan Meier"
    } else {
      mean_km <- sd_km <- NA
      mean_type <- "Arithmetic"
    } # else for KM
  } else {
    min_d <- min_d_qual <- max_d <- max_d_qual <- mean_d <- sd_d <- mean_km <- sd_km <- NA
    mean_type <- ""
    sigma <- n_detect_unique <- n_unique <- 0
  } # if fod>0

  sum_stat <- data.frame(
    n = n,
    n_unique = n_unique,
    n_detect = n_detect,
    n_detect_unique = n_detect_unique,
    fod = fod,
    min_d = min_d,
    min_d_qual = min_d_qual,
    max_d = max_d,
    max_d_qual = max_d_qual,
    mean_d = mean_d,
    sd_d = sd_d,
    sigma = sigma,
    mean_km = mean_km,
    sd_km = sd_km,
    mean_type = mean_type
  )

  # Distribution Testing ----------------------------------------------------------
  # sample size must be >3 and have at least 2 unique, detected values

  if (n_detect >= 4 & n_detect_unique > 2) {
    dist_all <- dist <- c()


    # Normal/Lognormal Distributions -------------------------------------------------------
    # Shapiro-wilks and Lilliefors GOF for Normality/Lognormality - QA

    # Shapiro-wilks
    if (length(x) <= 5000) {
      # normal
      sw_norm_resuts <- try(shapiro.test(x), silent = TRUE)
      sw_norm <- try(round(sw_norm_resuts$p.value, digits = 5), silent = TRUE)
      sw_norm_teststat <- try(round(sw_norm_resuts$statistic, digits = 5), silent = TRUE)
      spn <- pval_norm < sw_norm
      sw_norm <- signif(sw_norm, digits = 2)
      # lognormal
      sw_lnnorm_resuts <- try(shapiro.test(log(x)), silent = TRUE)
      sw_lnnorm <- try(round(sw_lnnorm_resuts$p.value, digits = 5), silent = TRUE)
      sw_lnnorm_teststat <- try(round(sw_lnnorm_resuts$statistic, digits = 5), silent = TRUE)
      spln <- pval_norm < sw_lnnorm
      sw_lnnorm <- signif(sw_lnnorm, digits = 2)
    } else {
      # normal
      sw_norm <- "N>5000"
      sw_norm_teststat <- "N>5000"
      spn <- FALSE
      # lognormal
      spln <- FALSE
      sw_lnnorm <- "N>5000"
      sw_lnnorm_teststat <- "N>5000"
    }

    # Lilliefors (more preferable with larger sample sizes [5 > N])
    if (length(x) > 5) {
      # normal
      lil_norm_results <- nortest::lillie.test(x)
      lil_norm <- lil_norm_results$p.value
      lil_norm_teststat <- round(lil_norm_results$statistic, digits = 5)
      l.norm <- pval_norm < lil_norm
      lil_norm <- signif(lil_norm, digits = 2)
      # lognormal
      lil_lnnorm_results <- nortest::lillie.test(log(x))
      lil_lnnorm <- lil_lnnorm_results$p.value
      lil_lnnorm_teststat <- round(lil_lnnorm_results$statistic, digits = 5)
      ln.norm <- pval_norm < lil_lnnorm
      lil_lnnorm <- signif(lil_lnnorm, digits = 2)
    } else {
      # normal
      lil_norm <- "N<=5"
      lil_norm_teststat <- "N<=5"
      l.norm <- FALSE
      # lognormal
      lil_lnnorm <- "N<=5"
      ln.norm <- FALSE
      lil_lnnorm_teststat <- "N<=5"
    }
    # normal fit
    nfit <- suppressWarnings(try(fitdistrplus::fitdist(x, "norm"), silent = TRUE))
    if (length(grep("try-error", class(nfit), value = T)) == 1) {
      nfit <- fitdistrplus::fitdist(x, "norm", method = "mme")
    }
    n.gof <- suppressWarnings(try(summary(nfit), silent = TRUE))

    if (length(grep("try-error", class(n.gof), value = TRUE)) != 1) {
      n.aic <- n.gof$aic
      n.bic <- n.gof$bic
    } else {
      n.aic <- n.bic <- NA
    }

    # lognormal fit
    names(ln.norm) <- names(spln) <- "lognormal"

    lnfit <- suppressWarnings(try(fitdistrplus::fitdist(x, "lnorm"), silent = TRUE))
    if (length(grep("try-error", class(lnfit), value = T)) == 1) {
      lnfit <- fitdistrplus::fitdist(x, "lnorm", method = "mme")
    }
    ln.gof <- suppressWarnings(try(summary(lnfit), silent = TRUE))

    if (length(grep("try-error", class(ln.gof), value = TRUE)) != 1) {
      ln.aic <- ln.gof$aic
      ln.bic <- ln.gof$bic
    } else {
      ln.aic <- ln.bic <- NA
    }

    # Gamma Distribution ---------------------------------------------------------------
    # gamma Fit (prefer estimation by Maximium Likelihood Estimation, but if not possible use Moment Matching Estimation)
    # TODO: this PRINTS an error that cannot easily be suppressed
    # possible solution here: https://stackoverflow.com/questions/2723034/suppress-output-of-a-function
    gamfit <- suppressWarnings(try(fitdistrplus::fitdist(x, "gamma", method = "mle"), silent = TRUE))
    
    if (length(grep("try-error", class(gamfit), value = TRUE)) == 1) {
      gamfit <- fitdistrplus::fitdist(x, "gamma", method = "mme")
    }

    # use fitdistrplus package to estimate shape and scale parameters from data
    k <- gamfit$estimate["shape"]

    # use fitdistrplus gof package to calculate gof statistics
    gam.gof <- suppressWarnings(try(fitdistrplus::gofstat(gamfit, fitname = "gamma"), silent = TRUE))

    if (length(grep("try-error", class(gam.gof), value = TRUE)) != 1) {
      ad.stat <- gam.gof$ad # Anderson-Darling statistic
      ks.stat <- gam.gof$ks # Kolmogorov-Smirnov statistic
      g.ad.cv <- gcritval(pval = pval_gamma, test = "ad", k, n = length(x))
      g.ks.cv <- gcritval(pval = pval_gamma, test = "ks", k, n = length(x))

      g.ad <- ad.stat < gcritval(pval = pval_gamma, test = "ad", shape = k, n = length(x))
      g.ks <- ks.stat < gcritval(pval = pval_gamma, test = "ks", shape = k, n = length(x))

      ks.stat <- signif(ks.stat, digits = 4)
      ad.stat <- signif(ad.stat, digits = 4)
      g.ks.cv <- signif(g.ks.cv, digits = 4)
      g.ad.cv <- signif(g.ad.cv, digits = 4)
    } else {
      ad.stat <- ks.stat <- g.ad.cv <- g.ks.cv <- NA
      g.ad <- g.ks <- FALSE
    }

    gam.aic.bic <- suppressWarnings(try(summary(gamfit), silent = TRUE))
    if (length(grep("try-error", class(gam.aic.bic), value = TRUE)) != 1) {
      g.aic <- gam.aic.bic$aic
      g.bic <- gam.aic.bic$bic
    } else {
      g.aic <- g.bic <- NA
    }


    # Normality Check for 1/3 and 1/4 transformation - UTL Gamma Decision statistic-------------
    # QA - Need to review

    # 1/3 Transformation
    nfit.3 <- suppressWarnings(try(fitdistrplus::fitdist(x^(1 / 3), "norm"), silent = TRUE))
    if (length(grep("try-error", class(nfit.3), value = T)) == 1) {
      nfit.3 <- fitdistrplus::fitdist(x^(1 / 3), "norm", method = "mme")
    }
    n.gof.3 <- suppressWarnings(try(summary(nfit.3), silent = TRUE))

    sw_norm_resuts.3 <- try(shapiro.test(x^(1 / 3)), silent = TRUE)
    sw_norm.3 <- try(round(sw_norm_resuts.3$p.value, digits = 5), silent = TRUE)
    sw_norm_teststat.3 <- try(round(sw_norm_resuts.3$statistic, digits = 5), silent = TRUE)
    spn.3 <- pval_norm < sw_norm
    sw_norm.3 <- signif(sw_norm.3, digits = 2)

    # 1/4 Transformation
    nfit.4 <- suppressWarnings(try(fitdistrplus::fitdist(x^(1 / 4), "norm"), silent = TRUE))
    if (length(grep("try-error", class(nfit.4), value = T)) == 1) {
      nfit.4 <- fitdistrplus::fitdist(x^(1 / 4), "norm", method = "mme")
    }
    n.gof.4 <- suppressWarnings(try(summary(nfit.4), silent = TRUE))

    sw_norm_resuts.4 <- try(shapiro.test(x^(1 / 4)), silent = TRUE)
    sw_norm.4 <- try(round(sw_norm_resuts.4$p.value, digits = 5), silent = TRUE)
    sw_norm_teststat.4 <- try(round(sw_norm_resuts.4$statistic, digits = 5), silent = TRUE)
    spn.4 <- pval_norm < sw_norm
    sw_norm.4 <- signif(sw_norm.4, digits = 2)

    # UTL Transformation Decision - QA need to add section to check if the data are normal and then decide between the two transformations with AIC/BIC
    if (all(is.numeric(n.gof.3$aic) & is.numeric(n.gof.4$aic))) {
      if (n.gof.3$aic > n.gof.4$aic) {
        sum_stat$utl_normal_transform <- "fourth.root"
      } else {
        sum_stat$utl_normal_transform <- "cube.root"
      }
    } else {
      sum_stat$utl_normal_transform <- NA
    }

    # Distribution selection for Normal, Gamma, Lognormal or Nonparametric-------------------------
    # Updated to mirror hierarchy for ProUCL 5.1

    test_results <- c(
      length(grep(TRUE, c(spn, l.norm), value = T)),
      length(grep(TRUE, c(g.ad, g.ks), value = T)), # table with sum of TRUE values by normal [1], gamma[2] and lognormal[3] GOF tests
      length(grep(TRUE, c(spln, ln.norm), value = T))
    )

    names(test_results) <- c("normal", "gamma", "lognormal")

    # add "approximate" to name of test (normal, lognormal, gamma) if only one GOF test passes
    if (length(names(test_results[test_results == 1])) > 0) {
      names(test_results) <- sapply(names(test_results), function(x) ifelse(x %in% names(test_results[test_results == 1]), paste0("approximate ", x), x))
    }

    # remove distributions with no passing GOF tests - QA
    # Nonparametric - if no remaining distributions then assign as "nonparametric"

    if (sum(test_results) > 0) {
      test_results <- test_results[test_results > 0]
    } else {
      test_results <- c(1)
      names(test_results) <- "nonparametric"
    }


    dist_all <- names(test_results)

    # Parametric hierarchy
    # Normal>Approximate Normal > Gamma/Lognormal > Approximate Gamma/Approximate Lognormal - QA

    if ("normal" %in% names(test_results)) {
      dist <- "normal"
    }
    if ("approximate normal" %in% names(test_results)) {
      dist <- "approximate normal"
    }
    if ("nonparametric" %in% names(test_results)) {
      dist <- "nonparametric"
    }

    # If one is approximate, but the other is not, then select the one that is not approximate
    if (length(dist) == 0 & length(unique(grepl("approximate", names(test_results)))) > 1) {
      dist <- names(test_results[which.max(test_results)])
    }
    # Gamma but not Lognormal OR Lognormal but not Gamma
    if (length(dist) == 0 & length(test_results) == 1) {
      dist <- names(test_results)
    }
    # Gamma/Lognormal or Approximate Gamma/Approximate Lognormal - determined by AIC criteria (Note: ProUCL 5.1 select Gamma regardless of fit)
    if (length(dist) == 0 & length(test_results) == 2 & g.aic < ln.aic) {
      dist <- grep("gamma", names(test_results), value = T)
    }
    if (length(dist) == 0 & length(test_results) == 2 & g.aic > ln.aic) {
      dist <- grep("lognormal", names(test_results), value = T)
    }


    # Format AIC/BIC numbers
    ifelse(is.numeric(g.aic), g.aic <- signif(g.aic, digits = 6), g.aic)
    ifelse(is.numeric(g.bic), g.bic <- signif(g.bic, digits = 6), g.bic)
    ifelse(is.numeric(n.aic), n.aic <- signif(n.aic, digits = 6), n.aic)
    ifelse(is.numeric(n.bic), n.bic <- signif(n.bic, digits = 6), n.bic)
    ifelse(is.numeric(ln.aic), ln.aic <- signif(ln.aic, digits = 6), ln.aic)
    ifelse(is.numeric(ln.bic), ln.bic <- signif(ln.bic, digits = 6), ln.bic)

    t1 <- data.frame(
      c1 = c("Distribution", "Normal", "Lognormal", "Gamma"),
      c2 = c("S-W\n(p-value)", sw_norm, sw_lnnorm, "-"),
      c3 = c("S-W\n(statistic)", sw_norm_teststat, sw_lnnorm_teststat, "-"),
      c4 = c("Lilliefors\n(p-value)", lil_norm, lil_lnnorm, "-"),
      c5 = c("Lilliefors\n(statistic)", lil_norm_teststat, lil_lnnorm_teststat, "-"),
      c6 = c("K-S\n(statistic)", "-", "-", ks.stat),
      c7 = c("K-S\n(crit val)", "-", "-", g.ks.cv),
      c8 = c("A-D\n(statistic)", "-", "-", ad.stat),
      c9 = c("A-D\n(crit val)", "-", "-", g.ad.cv),
      c10 = c("AIC", n.aic, ln.aic, g.aic),
      c11 = c("BIC", n.bic, ln.bic, g.bic),
      stringsAsFactors = F
    )
    # Add all GOF statistics and pvalues
    t2 <- t1
    names(t2) <- t2[1, ] # make the first row of the table be the columns names
    t2 <- t2[c(2:4), ] # remove first row of dataframe which are no the column names
    t2$pc <- 1 # add placeholder column for reshape

    t2 <- reshape(data = t2, direction = "wide", idvar = "pc", timevar = "Distribution")
    t2 <- t2[, names(t2)[!names(t2) %in% c("pc")]] # remove placeholder column for reshape
    t2 <- t2[, names(t2)[!names(t2) %in% c(
      "K-S\n(statistic).Normal",
      "K-S\n(crit val).Normal",
      "A-D\n(statistic).Normal",
      "A-D\n(crit val).Normal",
      "K-S\n(statistic).Lognormal",
      "K-S\n(crit val).Lognormal",
      "A-D\n(statistic).Lognormal",
      "A-D\n(crit val).Lognormal",
      "S-W\n(p-value).Gamma",
      "Lilliefors\n(p-value).Gamma",
      "S-W\n(statistic).Gamma",
      "Lilliefors\n(statistic).Gamma"
    )]] # Remove columns that do not make logical sense (i.e. no KS for Normal/Lognormal)

    t2 <- cbind(data.frame(gof_fit_type = fit_type), t2)
    t2 <- cbind(t2, data.frame(dist_all = paste(dist_all, collapse = ", "), dist_select = dist))
    names(t2) <- gsub("\n", "_", names(t2))
    names(t2) <- gsub("\\(", "_", names(t2))
    names(t2) <- gsub("\\)", "_", names(t2))
    names(t2) <- gsub("-", "_", names(t2))
    names(t2) <- gsub("\\.", "_", names(t2))
    names(t2) <- gsub(" ", "_", names(t2))
    names(t2) <- gsub("__", "_", names(t2))

    fitestimate <- qqcomp2(list(nfit, lnfit, gamfit), legendtext = c("Normal", "Lognormal", "Gamma"))
    fitestimate <- as.data.frame(fitestimate)
    names(fitestimate) <- c("Normal", "Lognormal", "Gamma")
    fitestimate$x <- x
    fitestimate$detected <- det

    if (fod == 0) {
      dist_all <- "none"
      dist <- "none"
      t1[t1$c1 != "Distribution", c(2:9)] <- "-"
      t2[1, ] <- NA
      nfit <- lnfit <- gamfit <- fitestimate <- NA
    }

    list(
      SummaryStats = sum_stat,
      Distribution = list(All = dist_all, Selected = dist),
      Table = t1,
      GOF_Stat = t2,
      Fit_Type = fit_type,
      Fits = list(nfit = nfit, lnfit = lnfit, gamfit = gamfit),
      Fitestimate = fitestimate
    )
  } else { # if n>=4
    shape <- rate <- 0
    names(shape) <- "shape"
    names(rate) <- "rate"

    t2 <- data.frame(
      gof_fit_type = NA,
      S_W_p_value_Normal = NA,
      Lilliefors_p_value_Normal = NA,
      AIC_Normal = NA,
      BIC_Normal = NA,
      S_W_p_value_Lognormal = NA,
      Lilliefors_p_value_Lognormal = NA,
      AIC_Lognormal = NA,
      BIC_Lognormal = NA,
      K_S_statistic_Gamma = NA,
      K_S_crit_val_Gamma = NA,
      A_D_statistic_Gamma = NA,
      A_D_crit_val_Gamma = NA,
      AIC_Gamma = NA,
      BIC_Gamma = NA,
      dist_all = "none",
      dist_select = "none"
    )

    list(
      SummaryStats = sum_stat,
      Distribution = list(All = "none", Selected = "none"),
      Table = NA,
      GOF_Stat = t2,
      Fit_Type = NA,
      Fits = list(nfit = NA, lnfit = NA, gamfit = list(estimate = c(shape, rate))),
      Fitestimate = NA
    )
  }
}
