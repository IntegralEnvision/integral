#' Hierarchy for choosing a UCL method
#'
#' Based on EPA's ProUCL hierarchy
#'
#' @format A data frame with 53940 rows and 10 variables:
#' \describe{
#'   \item{Preference}{}
#'   \item{N_min}{}
#'   \item{N_max}{}
#'   \item{Censored}{}
#'   \item{FOD_min}{}
#'   \item{FOD_max}{}
#'   \item{N_D_min}{}
#'   \item{N_D_max}{}
#'   \item{N_uniqueD_min}{}
#'   \item{N_uniqueD_max}{}
#'   \item{Distribution}{}
#'   \item{sigma_min}{}
#'   \item{sigma_max}{}
#'   \item{k_min}{}
#'   \item{k_max}{}
#'   \item{ucl_method}{}
#'   \item{ucl_method_name}{}
#'   \item{ucl_method_name2}{}
#'   \item{ucl_ci}{}
#'   \item{ucl_warning}{}
#'   \item{ucl_code}{}
#' }
"ProUCL"

#' Hierarchy for choosing a UTL method
#'
#' 
#'
#' @format A data frame with 53940 rows and 10 variables:
#' \describe{
#'   \item{Preference}{}
#'   \item{N_min}{}
#'   \item{N_max}{}
#'   \item{Censored}{}
#'   \item{FOD_min}{}
#'   \item{FOD_max}{}
#'   \item{N_D_min}{}
#'   \item{N_D_max}{}
#'   \item{N_uniqueD_min}{}
#'   \item{N_uniqueD_max}{}
#'   \item{Distribution}{}
#'   \item{utl_normal_transform}{}
#'   \item{ucl_method}{}
#'   \item{ucl_method_name}{}
#'   \item{ucl_method_name2}{}
#' }
"UTL_hier"