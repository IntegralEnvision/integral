#' @export
# ===============================================================================
#                       2021, Integral Consulting Inc.                         #
# ===============================================================================
# ===============================================================================
#  km_ple2.R                                         #
# ===============================================================================
# PURPOSE:
# 	Calculate summary statistics for subsequent UCL calculations using
# Kaplan-Meier (KM) algorithms.
#
# AUTHOR(S)
# 	Penelope Pooler Eisenbies
# Heather Summers (2017 updates)
# Katherine Heal (2021 updates)
#
# HISTORY:
#   Date           Remarks
#  -----------	   -------------------------------------------------------------
# 	 2015-09-17      Finalized function and prepared it for QA
#  2015-09-29      QA completed and function code revised
#  2017-05-25      H. Summers updates to vectorize loops to improve efficiency.
#  2021-11-17      K. Heal updates to incorporate faster calculations of nj, mj and FX
# ===============================================================================

# ===============================================================================
# 		ENVIRONMENT
#
# ===============================================================================
# 		FUNCTIONS

#------------------------------------------------------------------------------
# 	km_ple
#
# Arguments:
# dat: a dataframe with:
# first column: numeric values, including detection limits
# second column: booleans identifying the detection limits in 'data'
#
# ***NOTE: T or True if the concentration is BELOW the detection limit;
#         F or False if it is above the detection limit
#------------------------------------------------------------------------------

km_ple2 <- compiler::cmpfun(function(dat) {
  colnames(dat) <- c("x", "det")

  # convert boolean to 0/1
  dat$det[dat$det == T] <- 1

  # save preliminary sample size values
  n_d <- length(dat$x[dat$det == 1])
  v_d <- length(unique(dat$x[dat$det == 1]))

  # confirm data are ordered as needed
  d <- dat[order(dat$x, dat$det), ]

  # calculate nj (number of observations less than or equal to observation i)
  d$nj <- rank(d$x, ties.method = "max")

  # calculate mj (number of detects equal to observation i)
  if (length(d$x) > 400) {
    # faster on many obs
    d <- dplyr::ungroup(dplyr::mutate(dplyr::group_by(d, x), mj = sum(det == 1)))
    d <- as.data.frame(d)
  } else {
    # faster on few obs
    d$mj <- unlist(lapply(d$x, FUN = function(i) length(d$x[d$det == 1][d$x[d$det == 1] == i])))
  }

  # calculate needed ratio of nj and mj values
  d$n_m_n <- (d$nj - d$mj) / d$nj

  # # subset data to detects and min. value in data
  # # remove duplicated values
  d <- d[d$det == 1 | d$x == min(d$x), ]
  d <- d[!duplicated(d$x), ]

  # reverse order of data for next set of iterative calculations
  d <- d[order(-d$x), ]

  # calculate ECDF (F_x) as specified in algorithm
  # Note some aspects of algorithm support required translation from continuous theoretical explanation
  # to fit observed data
  d$seq <- seq.int(nrow(d))

  d$F_x <- NA
  d$F_x <- cumprod(d$n_m_n)

  mxdc1 <- max(d$x[d$det == 1], na.rm = T)
  mndc1 <- min(d$x[d$det == 1], na.rm = T)
  mndc <- min(d$x, na.rm = T)

  d$F_x[d$x > mxdc1] <- 1
  d$F_x[d$x == mndc] <- 0
  d$F_x[d$x < mndc1 & d$x > mndc] <- d$F_x[d$x == mndc1]


  # Calculate PDF from CDF
  d$f_x <- c(1, d[d$seq < nrow(d), "F_x"]) - d$F_x

  # Calculate heights, widths and areas of step function created by data (See Bechtel Jacobs 2000)
  d$height_above <- (1 - d$F_x)
  d$height_below <- d$F_x

  d$width2 <- d$x - c(d[d$seq > 1, "x"], 0)
  d$area_above <- d$width * d$height_above
  d$area_below <- d$width * d$F_x

  # re-order data to calculate SE_PLe
  d <- d[order(d$x), ]
  d$seq <- seq.int(nrow(d))

  # calculate grouped area below while accounting for two different cases:
  # Case 1: min x. is a detect
  # Case 2: min x. is a non-detect
  # Note: Pro-UCL treats both cases as Case 1 (see KM_PLE_PRO_UCL function below)
  # which differs from Bechtel-Jacobs (2000).
  d$gr_area_below <- NA
  if (d$det[d$x == min(d$x)] == 1) { # case 1
    d$gr_area_below <- cumsum(d$area_below)
    d$gr_area_below[1] <- NA
  }

  if (d$det[d$x == min(d$x)] == 0) { # case 2
    area_below_temp <- d$area_below
    area_below_temp[1:2] <- 0
    d$gr_area_below <- cumsum(area_below_temp)
    d$gr_area_below[1:2] <- NA
  }

  # square grouped area below values
  # create required product of nj and mj values
  d$gab2 <- d$gr_area_below * d$gr_area_below
  d$n_n_m <- d$nj * (d$nj - d$mj)
  d$n_n_m[is.na(d$gr_area_below)] <- NA

  # calculate components that will sum to create square of SE_PLE
  d$vrcmp <- d$mj * d$gab2 / d$n_n_m

  # calculate final summary stats
  mu_km_ple <- sum(d$area_above, na.rm = T)
  mu_km_dir <- sum(d$x * d$f_x)

  vr_km_dir <- sum(d$x^2 * d$f_x) - mu_km_dir^2
  sd_km_dir <- sqrt(vr_km_dir)
  se_sq_km_ple <- sum(d$vrcmp, na.rm = T) * (n_d / (n_d - 1))
  se_km_ple <- sqrt(se_sq_km_ple)

  # compile output
  Summaries <- c(mu_km_ple, vr_km_dir, sd_km_dir, se_km_ple)
  names(Summaries) <- c("Mean", "Variance", "Std_Dev", "SE_PLE")

  return(Summaries)
})
