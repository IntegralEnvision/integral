#' @importFrom stats var
#' @export

# boot_km_2 ---------------------------------------------------------------
# 	  boot_km
# boot_km implement boostrap resampling (with replacement) and calculate the KM Mean and KM standard Devation
# for each bootstrap resample that meets the criteria for number of distinct detect values.

# boot_km will output a warning if the number of distinct detected values in the data does
# not meet the minimum criteria recommended by Pro_UCL documentation

# Arguments:
# 	x:	A vector of numeric values, including detection limits
# 	det:	A vector of booleans identifying the detection limits in 'data'
# ns: Number of bootstrap resamples.  2000 is the default in Pro-UCL 5.0
#
# ***NOTE: det = T or True if the concentration is ABOVE the detection limit and F or False if it is below the detection limit
#

boot_km_2 <- compiler::cmpfun(function(x, det, ns = 1000) {
  d <- data.frame(x, det)

  # create ns # of shuffled dataframes
  tmp <- replicate(ns, d[sample(nrow(d), nrow(d), replace = T), ], simplify = F)

  # dump any instances where there are fewer that 3 dets
  tmp <- tmp[lapply(tmp, function(tmp) length(unique(tmp[tmp$det == TRUE, "x"]))) >= 3]

  # perform km_ple on each
  if (length(tmp) > 0) {
    boots <- lapply(tmp, function(i) km_ple2(i))

    boots <- dplyr::bind_rows(boots)
    mnb <- boots$Mean
    sdb <- boots$Std_Dev
    boots <- data.frame(mnb, sdb)
    boots.nm <- boots[!is.na(boots[1]), ]
    boots.nm
  } else {
    "Too few unique detected samples to bootstrap."
  }
})


# boot_ucl ----------------------------------------------------------------
# 	  boot_ucl
#   Implements bootstrap resampling and saves the mean and and standard deviation of each resample
#
# Arguments:
# 	x:	A vector of numeric values, including detection limits
# ns: Numberof bootstrap resamples.  2000 is the default in Pro-UCL 5.0
#
boot_ucl <- compiler::cmpfun(function(x, ns = 1000) {
  tmp <- replicate(ns, sample(x, length(x), replace = T), simplify = F)
  tmp <- tmp[purrr::map(tmp, function(i) length(unique(i))) > 1]

  if (length(tmp) > 0) {
    boots <- lapply(tmp, boot_stat)
    boots <- dplyr::bind_rows(boots)
    boots.nm <- boots[!is.na(boots[1]), ]
    return(boots.nm)
  } else {
    return("Too few unique samples to bootstrap.")
  }
})


# boot_stat ---------------------------------------------------------------
# 	  boot_stat
#   Calculates boot strapping statistics, mean, sd, u(hat) and k(hat) per ProUCL 5.1 guidance
#   u(hat) - equation 2-38
#   k(hat) - equation 2-43
#
# Arguments:
# 	x:	A vector of numeric values
#
# NOTES:
# need to look into C++ coding

boot_stat <- compiler::cmpfun(function(x) {
  mnb <- mean(x)
  sdb <- sqrt(var(x))
  mu_hat <- length(x) * sum((x - mnb)^3) / ((length(x) - 1) * (length(x) - 2))
  khat <- mu_hat / sdb^3
  boot_stats <- c(mnb, sdb, mu_hat, khat)
  names(boot_stats) <- c("mnb", "sdb", "mu_hat_3b", "khat_3b")
  return(boot_stats)
})
