#' @importFrom dplyr distinct
#' @export


# UtL Implementation script
utl <- function(x,
                det,
                quals = NA,
                con_lvl = 0.95,
                cover = 0.95,
                method = "All", # or "Custom",
                method.custom = NA) {

  # Dummy boot input -----
  boot <- FALSE
  # browser()
  # Check data input types -----
  assertthat::assert_that(
    length(x) == length(det),
    is.numeric(c(x)),
    is.logical(c(boot, det))
  )

  # Get gof output ----
  gof <- suppressWarnings(proucl_gof(x, det, quals, include_nd = F))

  # Full list of utl fxns -----
  utl_all <- c(
    "utl_normal", "utl_normal_cenkm",
    "utl_lognormal", "utl_lognormal_cenkm", "utl_lognormal_cenros",
    "utl_gammaOPT", "utl_gammaOPT_cenkm", "utl_gammaOPT_cenros",
    "utl_gammaWH", "utl_gammaWH_cenkm", "utl_gammaWH_cenros",
    "utl_gammaHW", "utl_gammaHW_cenkm", "utl_gammaHW_cenros",
    "utl_nonparam", "utl_max"
  )

  # Check that method and method.custom match appropriately ------
  if (method == "Custom") { # Custom method input check
    if (length(method.custom) != 1 | !all(method.custom %in% utl_all)) {
      stop("METHOD ERROR: Custom method must have exactly 1 appropriate method.custom argument.")
    }
  }

  # ________________________________________________
  # ProUCL Selected UTL method -----
  ## Get selected distribution ----
  sum_stat <- gof$SummaryStats

  # Select appropriate UTL methods -----
  UTL_hier <- rUCLs::UTL_hier


  if (method == "Custom" & sum_stat$n_detect > 0) { # "Custom"
    sutl <- distinct(UTL_hier[
      UTL_hier$utl_method == method.custom,
      c(
        "utl_method", "utl_method_name",
        "utl_method_name2"
      )
    ])
    utl_select <- data.frame(
      utl_select_method = sutl$utl_method_name2,
      utl_select_value = NA,
      utl_select_ach_conf = NA,
      utl_select_warning = NA
    )
    utl_select_method <- method.custom
    alt_sutls <- NA
  }
  if (sum_stat$n_detect == 0) { # all non detects
    utl_select <- data.frame(
      utl_select_method = "Not Detected",
      utl_select_value = NA,
      utl_select_ach_conf = NA,
      utl_select_warning = NA
    )

    utl_select_method <- NA
    alt_sutls <- NA
  }

  # ________________________________________________
  ## All non-detects scenario ----
  if (sum_stat$n_detect == 0) {
    out <- t(data.frame(value = rep(NA, length(utl_all))))
    colnames(out) <- utl_all
  } else {
    boots <- NA

    ## All detects scenario -----
    if (length(unique(det)) == 1 & sum_stat$n_detect >= 3) { # >=3 all detects
      if (method %in% c("Custom") &
        TRUE %in% (grepl("cen", method.custom))) { # Custom method check
        stop("METHOD ERROR: Data are all detected.
               Select method(s) without censoring.")
      }
      # Start with full list of non-censored utls (for both All and Custom)
      utl_names <- grep("cen", utl_all, value = T, invert = T)
    }
  } # if all detected

  ## Mixed detects and non-detects scenario ----
  if (length(unique(det)) > 1 & sum_stat$n_detect >= 3) { # >=3 mixed detects
    if (method %in% c("Custom") &
      FALSE %in% (grepl("cen", method.custom))) { # Custom method check
      stop("METHOD ERROR: Data contain nondetects.
               Select method(s) with censoring.")
    }
    # Start with full list of censored utls (for both All and Custom)
    utl_names <- c(grep("cen", utl_all, value = T), "utl_max", "utl_nonparam")
  } # if mix
  # ________________________________________________
  ## Less than 3 detected values scenario -----
  # Need to decide programmatically if a value calculated with 3 samples is valid though.
  if (method %in% c("Custom") &
    (sum_stat$n_detect < 3) &
    FALSE %in% (grepl("utl_max", method.custom))) { # Custom method check
    stop("METHOD ERROR: Data contain less than 3 detects
                 It is suggested to have 8 to 10 observations before calculating a UTL.")
    # QA - 12/29/2021 - HMS - Changed this message
    # Should also put this message on any samples with fewer than 10 data points.
  }
  if (sum_stat$n_detect < 3) {
    utl_names <- "utl_max"
    boots <- NA
  } # if N<3

  # Perform utl methods chosen ----
  out <- t(data.frame(
    values = sapply(
      utl_names, function(meth) {
        suppressWarnings(
          call_utl_method(meth, x, det, con_lvl, cover, boots)[[1]]
        )
      }
    )
  ))

  ## Clean up ucl output----
  outna <- t(data.frame(value = rep(
    NA, length(utl_all[!utl_all %in% colnames(out)])
  )))
  colnames(outna) <- utl_all[!utl_all %in% colnames(out)]

  # Final Output
  out <- cbind(out, outna)
  out <- as.data.frame(out)
  row.names(out) <- NULL
  # ________________________________________________-
  # browser()

  # Final data output mods ----
  sum_stat <- cbind(sum_stat, gof$GOF_Stat)
  sum_stat$conf_lvl <- con_lvl
  sum_stat$cover <- cover
  out <- cbind(sum_stat, out)
  if (sum_stat$n_detect > 0 & method == "Custom") { # get UTL select values
    utl_select_output <- call_utl_method(
      utl_select_method, x,
      det, con_lvl, cover, boots
    )
    utl_select$utl_select_value <- utl_select_output[[1]]
    utl_select$utl_select_ach_conf <- utl_select_output[[2]]
    out <- cbind(out, utl_select)
  }
  
  # Add warnings -------
  add_warning <- c()
  
  if (sum_stat$n_detect < 11){
    add_warning <- c(
      add_warning, "It is suggested to have 8 to 10 observations before calculating a UTL.")
  }

  if (sum_stat$fod < 0.2){
    add_warning <- c(
      add_warning, "ROS methods are not suggested for FOD < 0.2")
  }
  ## Combine warnings -----
  out$utl_warning <- paste0(add_warning, collapse = " ")
  
  
  
  
  
  return(out)
} # function
