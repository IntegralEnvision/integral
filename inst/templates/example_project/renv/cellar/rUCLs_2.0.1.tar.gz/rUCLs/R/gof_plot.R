#' @importFrom graphics par abline mtext plot.new points
#' @export

# Function to create GOF output

gof_plot <- function(x, x_d, media = NA, exposure_unit = NA, 
                     chemical = NA, doc.title = NA, 
                     fig.title = NA, fig.num = NA, notes = NA, 
                     quals = c(TRUE, FALSE)) {


  # x is an object from ProUCL_GOF function with NDs included
  # x_d is an object from ProUCL_GOF function with only detects
  if (is.na(doc.title)) {
    doc.title <- ""
  }
  if (is.na(fig.title)) {
    fig.title <- ""
  }
  if (is.na(fig.num)) {
    fig.num <- ""
  }
  if (is.na(notes)) {
    notes <- ""
  }
  # Figure
  par(new = F)
  plot.new()
  mtext("", side = 1, line = 0)

  figure_template(orient = "P", doc.title, fig.title, fig.num, notes)

  vp1 <- grid::viewport(x = 0, y = 1, h = .275, w = 1, just = c("left", "top")) # set up view for GOF plots
  grid::pushViewport(vp1)
  grid::grid.rect() # figure

  vp1.1 <- grid::viewport(x = 0, y = 1, h = 1, w = .25, just = c("left", "top")) # child of vp1
  grid::pushViewport(vp1.1)
  vp1.1.1 <- grid::viewport(x = 0, y = 1, h = .5, w = 1, just = c("left", "top")) # child of vp1.1
  grid::pushViewport(vp1.1.1)
  grid::grid.rect() # figure
  ifelse(nchar(media) > 24 & !is.na(media), m2 <- paste(strwrap(media, width = 24), collapse = "\n"), m2 <- media)
  ifelse(nchar(media) > 24 & !is.na(media), space <- "\n", space <- "")
  grid::grid.text(paste0("Media:\n", space, "\nExposure Unit:\n", "\nChemical:\n"), x = .05, y = .98, just = c("left", "top"), gp = grid::gpar(fontsize = 10, fontface = "bold"))

  grid::grid.text(paste0("\n  ", m2, "\n\n  ", exposure_unit, "\n\n  ", chemical), x = .05, y = .98, just = c("left", "top"), gp = grid::gpar(fontsize = 10))
  grid::upViewport()

  vp1.1.2 <- grid::viewport(x = 0, y = .5, h = .5, w = 1, just = c("left", "top")) # child of vp1.1
  grid::pushViewport(vp1.1.2)
  grid::grid.rect() # figure
  grid::grid.text(paste0("Legend"), x = .5, y = .95, just = c("centre", "top"), gp = grid::gpar(fontsize = 10, fontface = "bold"))
  grid::grid.text(paste0("Normal\nLognormal\nGamma\nDetect\nNondetect (ROS)"), x = .35, y = .75, just = c("left", "top"), gp = grid::gpar(fontsize = 10))
  grid::grid.lines(c(.14, .3), c(.725, .725), gp = grid::gpar(col = "skyblue", lwd = 3))
  grid::grid.lines(c(.14, .3), c(.565, .565), gp = grid::gpar(col = "palegreen4", lwd = 3))
  grid::grid.lines(c(.14, .3), c(.415, .415), gp = grid::gpar(col = "coral", lwd = 3))
  grid::grid.points(x = .24, y = .27, pch = 20, gp = grid::gpar(cex = 1))
  grid::grid.points(x = .24, y = .13, pch = 21, gp = grid::gpar(cex = .75, col = "black"))

  grid::upViewport(2)

  vp1.2 <- grid::viewport(x = .25, y = 1, h = 1, w = .75, just = c("left", "top")) # child of vp1
  grid::pushViewport(vp1.2)
  grid::grid.rect() # figure
  vp1.2.1 <- grid::viewport(x = 0, y = 1, h = .1, w = 1, just = c("left", "top")) # child of vp2
  grid::pushViewport(vp1.2.1)
  grid::grid.rect(gp = grid::gpar(fill = "lightblue"))
  grid::grid.text("Q-Q Plot (All Data)", x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 11, fontface = "bold"))
  grid::upViewport()
  vp1.2.2 <- grid::viewport(x = .55, y = .54, h = .52, w = .8, just = c("centre", "centre")) # child of vp1
  grid::pushViewport(vp1.2.2)
  par(plt = gridBase::gridPLT(), new = TRUE, ps = 10, mgp = c(2, 1, 0))

  # Create Q-Q Plot with all Data

  if (x[["SummaryStats"]]$n_detect < 4) {
    grid::grid.text("Number of detects <4.", x = .5, y = .5, gp = grid::gpar(fontsize = 14))
  } else {
    plot(x$Fitestimate$x ~ x$Fitestimate$Normal, pch = ifelse(x$Fitestimate$det == FALSE, 21, 16), col = "skyblue", xlim = c(0, max(x$Fitestimate[, c("Normal", "Lognormal", "Gamma", "x")])), ylim = c(0, max(x$Fitestimate[, c("Normal", "Lognormal", "Gamma", "x")])), xlab = "Theoretical quantiles", ylab = "Empirical quantiles")
    points(x$Fitestimate$x ~ x$Fitestimate$Lognormal, pch = ifelse(x$Fitestimate$det == FALSE, 21, 16), col = "palegreen4")
    points(x$Fitestimate$x ~ x$Fitestimate$Gamma, pch = ifelse(x$Fitestimate$det == FALSE, 21, 16), col = "coral")
    abline(0, 1)



    if (x[["SummaryStats"]]$fod < .2) {
      grid::grid.text("FOD <20%, ROS imputed nondetect results are tenuous.", x = .95, y = .95, just = c("right", "top"), gp = grid::gpar(fontsize = 8))
    }
  }
  grid::upViewport(3)


  vp2 <- grid::viewport(x = 0, y = .725, h = .3, w = 1, just = c("left", "top")) # set up view for GOF plots
  grid::pushViewport(vp2)
  grid::grid.rect()

  vp2.1 <- grid::viewport(x = 0, y = 1, h = .1, w = 1, just = c("left", "top")) # child of vp2
  grid::pushViewport(vp2.1)
  grid::grid.rect(gp = grid::gpar(fill = "lightblue"))
  grid::grid.text("ECDF, Histogram & Q-Q (Detects Only)", x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 11, fontface = "bold"))
  grid::upViewport()

  vp2.2 <- grid::viewport(x = 0, y = .9, h = .9, w = 1, just = c("left", "top")) # child of vp2
  grid::pushViewport(vp2.2)
  grid::grid.rect()

  if (x[["SummaryStats"]]$n_detect < 4) {
    grid::grid.text("Number of detects <4.", x = .5, y = .5, gp = grid::gpar(fontsize = 14))
  } else {
    vp2.2.1 <- grid::viewport(x = 0, y = 1, h = 1, w = 0.33, just = c("left", "top")) # child of vp2.2
    grid::pushViewport(vp2.2.1)
    grid::grid.rect()

    vp2.2.1.1 <- grid::viewport(x = .58, y = .52, h = .55, w = .6, just = c("centre", "centre")) # child of vp2.2
    grid::pushViewport(vp2.2.1.1)
    par(plt = gridBase::gridPLT(), new = TRUE, ps = 10)
    fitdistrplus::cdfcomp(x_d$Fits, main = "ECDF", addlegend = FALSE, xlab = paste0(chemical, " Conc."), fitcol = c("skyblue", "palegreen4", "coral"), cex = .7)
    grid::upViewport(2)

    vp2.2.2 <- grid::viewport(x = .33, y = 1, h = 1, w = 0.34, just = c("left", "top")) # child of vp2.2
    grid::pushViewport(vp2.2.2)
    grid::grid.rect()
    vp2.2.1.2 <- grid::viewport(x = .58, y = .52, h = .55, w = .6, just = c("centre", "centre")) # child of vp2.2
    grid::pushViewport(vp2.2.1.2)
    par(plt = gridBase::gridPLT(), new = TRUE, ps = 10)
    suppressWarnings(fitdistrplus::denscomp(x_d$Fits, main = "Histogram", addlegend = FALSE, xlab = paste0(chemical, " Conc."), fitcol = c("skyblue", "palegreen4", "coral"), cex = .7))
    grid::upViewport(2)


    vp2.2.3 <- grid::viewport(x = 0.67, y = 1, h = 1, w = 0.33, just = c("left", "top")) # child of vp2.2
    grid::pushViewport(vp2.2.3)
    grid::grid.rect()
    vp2.2.1.3 <- grid::viewport(x = .58, y = .52, h = .55, w = .6, just = c("centre", "centre")) # child of vp2.2
    grid::pushViewport(vp2.2.1.3)
    par(plt = gridBase::gridPLT(), new = TRUE, ps = 10)
    fitdistrplus::qqcomp(x_d$Fits, main = "Q-Q", addlegend = FALSE, fitcol = c("skyblue", "palegreen4", "coral"), cex = .7)

    grid::upViewport(2)
  }
  grid::upViewport(2)

  vp3 <- grid::viewport(x = 0, y = .425, h = .425, w = 1, just = c("left", "top")) # set up view for GOF plots
  grid::pushViewport(vp3)
  grid::grid.rect()

  vp3.1 <- grid::viewport(x = 0, y = 1, h = .1, w = 1, just = c("left", "top")) # child of vp3
  grid::pushViewport(vp3.1)
  grid::grid.rect()

  ifelse(x[["SummaryStats"]]$mean_type == "Kaplan Meier", md <- x[["SummaryStats"]]$mean_km, md <- x[["SummaryStats"]]$mean_d)
  ifelse(x[["SummaryStats"]]$mean_type == "Kaplan Meier", sdd <- x[["SummaryStats"]]$sd_km, sdd <- x[["SummaryStats"]]$sd_d)
  mtype <- x[["SummaryStats"]]$mean_type

  grid::grid.text(paste0("N = ", x[["SummaryStats"]]$n), x = .05, y = .85, just = c("left", "top"), gp = grid::gpar(fontsize = 9))
  grid::grid.text(paste0("N (detect) = ", x[["SummaryStats"]]$n_detect), x = .05, y = .4, just = c("left", "top"), gp = grid::gpar(fontsize = 9))

  grid::grid.text(paste0("FOD = ", paste0(round((x[["SummaryStats"]]$fod * 100), 0), "%")), x = .25, y = .85, just = c("left", "top"), gp = grid::gpar(fontsize = 9))
  grid::grid.text(paste0("SD (log detect) = ", signif(x[["SummaryStats"]]$sigma, digits = 2)), x = .25, y = .4, just = c("left", "top"), gp = grid::gpar(fontsize = 9))


  grid::grid.text(paste0("Min (detect) = ", ifelse(is.numeric(x[["SummaryStats"]]$min_d), ifelse(x[["SummaryStats"]]$min_d > 1, paste(formatC(signif(x[["SummaryStats"]]$min_d, digits = 2), format = "d", big.mark = ","), x[["SummaryStats"]]$min_d_qual, sep = " "), paste(signif(x[["SummaryStats"]]$min_d, digits = 2), x[["SummaryStats"]]$min_d_qual, sep = " ")), x[["SummaryStats"]]$min_d)), x = .48, y = .85, just = c("left", "top"), gp = grid::gpar(fontsize = 9))
  grid::grid.text(paste0("Max (detect) = ", ifelse(is.numeric(x[["SummaryStats"]]$max_d), ifelse(x[["SummaryStats"]]$max_d > 1, paste(formatC(signif(x[["SummaryStats"]]$max_d, digits = 2), format = "d", big.mark = ","), x[["SummaryStats"]]$max_d_qual, sep = " "), paste(signif(x[["SummaryStats"]]$max_d, digits = 2), x[["SummaryStats"]]$max_d_qual, sep = " ")), x[["SummaryStats"]]$max_d)), x = .48, y = .4, just = c("left", "top"), gp = grid::gpar(fontsize = 9))

  grid::grid.text(paste0(mtype, " Mean = ", ifelse(is.numeric(md), ifelse(md > 1, formatC(signif(md, digits = 2), format = "d", big.mark = ","), signif(md, digits = 2)), md)), x = .74, y = .85, just = c("left", "top"), gp = grid::gpar(fontsize = 9))
  grid::grid.text(paste0(mtype, " SD = ", ifelse(is.numeric(sdd), ifelse(sdd > 1, formatC(signif(sdd, digits = 2), format = "d", big.mark = ","), signif(sdd, digits = 2)), sdd)), x = .74, y = .4, just = c("left", "top"), gp = grid::gpar(fontsize = 9))




  grid::upViewport()

  vp3.2 <- grid::viewport(x = 0, y = .9, h = .31, w = 1, just = c("left", "top")) # child of vp3
  grid::pushViewport(vp3.2)
  grid::grid.rect()

  vp3.2.1 <- grid::viewport(x = 0, y = 1, h = .17, w = 1, just = c("left", "top")) # child of vp3.2
  grid::pushViewport(vp3.2.1)
  grid::grid.rect(gp = grid::gpar(fill = "lightblue"))
  grid::grid.text("Goodness of Fit (All)", x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 11, fontface = "bold"))
  grid::upViewport()


  vp3.2.2 <- grid::viewport(x = 0, y = .83, h = .83, w = 1, just = c("left", "top")) # child of vp3.2
  grid::pushViewport(vp3.2.2)
  grid::grid.rect()

  if (x[["SummaryStats"]]$n_detect < 4) {
    grid::grid.text("Number of detects <4.", x = .5, y = .5, gp = grid::gpar(fontsize = 14))
  } else {
    ifelse(x$Distribution$Selected == "approximate normal", ds <- "normal",
      ifelse(x$Distribution$Selected == "approximate lognormal", ds <- "lognormal",
        ifelse(x$Distribution$Selected == "approximate gamma", ds <- "gamma", ds <- x$Distribution$Selected)
      )
    )

    ifelse(ds == "nonparametric", ds.fill <- NA, ds.fill <- grep(paste0("^", ds), tolower(x$Table$c1)) + 1)
    for (i in 2:5) { # child of 3.2.2
      for (j in 1:9) {
        if (i == 2 & j == 1) {
          grid::pushViewport(grid::viewport(x = 0, y = 1, h = 2 / 5, w = 1 / 9, just = c("left", "top")))
          grid::grid.text(x$Table[i - 1, j], x = .02, y = .5, just = c("left", "centre"), gp = grid::gpar(fontsize = 10, fontface = "bold"))
        }
        if (i == 2 & j > 1) {
          grid::pushViewport(grid::viewport(x = 0 + (j - 1) / 9, y = 1, h = 2 / 5, w = 1 / 9, just = c("left", "top")))
          grid::grid.text(x$Table[i - 1, j], x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 10, fontface = "bold"))
        }
        if (i > 2 & j == 1) {
          grid::pushViewport(grid::viewport(x = 0, y = 1 - ((i - 1) / 5), h = 1 / 5, w = 1 / 9, just = c("left", "top")))
          if (!(is.na(ds.fill)) & i == ds.fill & x[["SummaryStats"]]$fod == 1) {
            grid::grid.rect(gp = grid::gpar(fill = "lightgreen"))
          }
          grid::grid.text(x$Table[i - 1, j], x = .02, y = .5, just = c("left", "centre"), gp = grid::gpar(fontsize = 10, fontface = "bold"))
        }
        if (i > 2 & j > 1) {
          grid::pushViewport(grid::viewport(x = 0 + (j - 1) / 9, y = 1 - ((i - 1) / 5), h = 1 / 5, w = 1 / 9, just = c("left", "top")))
          if (!(is.na(ds.fill)) & i == ds.fill & x[["SummaryStats"]]$fod == 1) {
            grid::grid.rect(gp = grid::gpar(fill = "lightgreen"))
          }
          grid::grid.text(x$Table[i - 1, j], x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 10))
        }
        grid::grid.rect()
        grid::upViewport()
      }
    }
  }
  grid::upViewport(2)


  vp3.3 <- grid::viewport(x = 0, y = .59, h = .31, w = 1, just = c("left", "top")) # child of vp3
  grid::pushViewport(vp3.3)
  grid::grid.rect()

  vp3.3.1 <- grid::viewport(x = 0, y = 1, h = .17, w = 1, just = c("left", "top")) # child of vp3.3
  grid::pushViewport(vp3.3.1)
  grid::grid.rect(gp = grid::gpar(fill = "lightblue"))
  grid::grid.text("Goodness of Fit (Detects Only)", x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 11, fontface = "bold"))
  grid::upViewport()


  vp3.3.2 <- grid::viewport(x = 0, y = .83, h = .83, w = 1, just = c("left", "top")) # child of vp3.3
  grid::pushViewport(vp3.3.2)
  grid::grid.rect()

  if (x[["SummaryStats"]]$fod == 1) {
    grid::grid.text("All Detects", x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 14, fontface = "bold"))
  } else {
    if (x_d[["SummaryStats"]]$n_detect < 4) {
      grid::grid.text("Number of detects <4.", x = .5, y = .5, gp = grid::gpar(fontsize = 14))
    } else {
      ifelse(x_d$Distribution$Selected == "approximate normal", ds <- "normal",
        ifelse(x_d$Distribution$Selected == "approximate lognormal", ds <- "lognormal",
          ifelse(x_d$Distribution$Selected == "approximate gamma", ds <- "gamma", ds <- x_d$Distribution$Selected)
        )
      )
      ifelse(ds == "nonparametric", ds.fill <- NA, ds.fill <- grep(paste0("^", ds), tolower(x_d$Table$c1)) + 1)

      for (i in 2:5) { # child of 3.3.2
        for (j in 1:9) {
          if (i == 2 & j == 1) {
            grid::pushViewport(grid::viewport(x = 0, y = 1, h = 2 / 5, w = 1 / 9, just = c("left", "top")))
            grid::grid.text(x_d$Table[i - 1, j], x = .02, y = .5, just = c("left", "centre"), gp = grid::gpar(fontsize = 10, fontface = "bold"))
          }
          if (i == 2 & j > 1) {
            grid::pushViewport(grid::viewport(x = 0 + (j - 1) / 9, y = 1, h = 2 / 5, w = 1 / 9, just = c("left", "top")))
            grid::grid.text(x_d$Table[i - 1, j], x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 10, fontface = "bold"))
          }
          if (i > 2 & j == 1) {
            grid::pushViewport(grid::viewport(x = 0, y = 1 - ((i - 1) / 5), h = 1 / 5, w = 1 / 9, just = c("left", "top")))
            if (!(is.na(ds.fill)) & i == ds.fill & x[["SummaryStats"]]$fod < 1) {
              grid::grid.rect(gp = grid::gpar(fill = "lightgreen"))
            }
            grid::grid.text(x_d$Table[i - 1, j], x = .02, y = .5, just = c("left", "centre"), gp = grid::gpar(fontsize = 10, fontface = "bold"))
          }
          if (i > 2 & j > 1) {
            grid::pushViewport(grid::viewport(x = 0 + (j - 1) / 9, y = 1 - ((i - 1) / 5), h = 1 / 5, w = 1 / 9, just = c("left", "top")))
            if (!(is.na(ds.fill)) & i == ds.fill & x[["SummaryStats"]]$fod < 1) {
              grid::grid.rect(gp = grid::gpar(fill = "lightgreen"))
            }
            grid::grid.text(x_d$Table[i - 1, j], x = .5, y = .5, just = c("centre", "centre"), gp = grid::gpar(fontsize = 10))
          }

          grid::grid.rect()
          grid::upViewport()
        }
      }
    }
  }
  grid::upViewport(2)
  grid::grid.text("Selected distribution highlighted in green.", x = .01, y = .266, just = c("left", "top"), gp = grid::gpar(fontsize = 9.5))
  grid::grid.text("- = not calculated\nA-D = Anderson-Darling\nAIC = Akaike information criterion\nBIC = Bayesian information criterion\nECDF = empirical cumulative\ndistribution function\nFOD = frequency of detection",
    x = 0.01, y = .17, just = c("left", "top"), gp = grid::gpar(fontsize = 5)
  )
  grid::grid.text("K-S = Kolmogorov-Smirnov\nN = number of samples\nQ-Q = quantile-quantile\nROS = Regression on order statistics\nS-W = Shapiro-Wilk\nSD = standard deviation",
    x = 0.18, y = .225, just = c("left", "top"), gp = grid::gpar(fontsize = 5)
  )

  grid::upViewport()
}
