#' @importFrom stats qnorm pbinom pf qt
#' @export

# utl_normal ----
utl_normal <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  value <- EnvStats::tolIntNorm(x,
    ti.type = "upper",
    method = "exact",
    cov.type = "content",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]
  names(value) <- NULL
  achiv_conf <- NA
  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_normal_cenkm ----
utl_normal_cenkm <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  if (length(x) > 30) {
    # Approximation method (Natrella 1963)
    aa <- 1 - ((qnorm(cl)^2) / (2 * (length(x) - 1)))
    bb <- (qnorm(cover)^2) - (qnorm(cl)^2) / length(x)
    k1 <- (qnorm(cover) + sqrt((qnorm(cover)^2) - aa * bb)) / aa
  } else {
    # non-central t-distribution method
    delta <- qnorm(cover) * sqrt(length(x))
    k1 <- qt(cl, length(x) - 1, ncp = delta) / sqrt(length(x))
  }
  km_smry <- km_ple2(data.frame(x, det))
  KM_mean <- km_smry[1]
  KM_var <- km_smry[2]
  value <- KM_mean + k1 * (KM_var)^1 / 2
  names(value) <- NULL
  achiv_conf <- NA
  utl <- list(value, achiv_conf)
  return(utl)
})


# utl_lognormal -----
utl_lognormal <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  value <- EnvStats::tolIntLnorm(x,
    ti.type = "upper",
    method = "exact",
    cov.type = "content",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]
  achiv_conf <- NA
  names(value) <- NULL
  utl <- list(value, achiv_conf)
  return(utl)
})


# utl_lognormal_cenkm -----
utl_lognormal_cenkm <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  if (length(x) > 30) {
    # Approximation method (Natrella 1963)
    aa <- 1 - ((qnorm(cl)^2) / (2 * (length(x) - 1)))
    bb <- (qnorm(cover)^2) - (qnorm(cl)^2) / length(x)
    k1 <- (qnorm(cover) + sqrt((qnorm(cover)^2) - aa * bb)) / aa
  } else {
    # non-central t-distribution method
    delta <- qnorm(cover) * sqrt(length(x))
    k1 <- qt(cl, length(x) - 1, ncp = delta) / sqrt(length(x))
  }
  km_smry <- km_ple2(data.frame(log10(x), det))
  KM_mean <- km_smry[1]
  KM_sd <- km_smry[3]
  value <- exp(KM_mean + k1 * KM_sd)
  achiv_conf <- NA
  names(value) <- NULL

  utl <- list(value, achiv_conf)
  return(utl)
})


# utl_lognormal_cenros -----
utl_lognormal_cenros <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  # input x
  # QA - should we be running an ROS any time it's possible or within FOD limits like the proucl_gof function?

  data <- suppressWarnings(NADA::cenros(x, !det)) # in cenrose fxn, TRUE = nd
  d.ROS <- data.frame(x = data$modeled, det = !(data$censored))
  d.ROS <- d.ROS[order(d.ROS$x), ]
  x_ros <- d.ROS$x

  if (is.numeric(length(x_ros))) {
    x <- x_ros
  }

  # calc utl with new x
  value <- EnvStats::tolIntLnorm(x,
    ti.type = "upper",
    method = "exact",
    cov.type = "content",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]
  achiv_conf <- NA
  names(value) <- NULL

  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaWH -----
utl_gammaWH <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  value <- EnvStats::tolIntGamma(x,
    ti.type = "upper",
    method = "exact",
    est.method = "mle",
    normal.approx.transform = "cube.root",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]
  achiv_conf <- NA
  names(value) <- NULL
  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaWH_cenkm -----
utl_gammaWH_cenkm <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  if (length(x) > 30) {
    # Approximation method (Natrella 1963)
    aa <- 1 - ((qnorm(cl)^2) / (2 * (length(x) - 1)))
    bb <- (qnorm(cover)^2) - (qnorm(cl)^2) / length(x)
    k1 <- (qnorm(cover) + sqrt((qnorm(cover)^2) - aa * bb)) / aa
  } else {
    # non-central t-distribution method
    delta <- qnorm(cover) * sqrt(length(x))
    k1 <- qt(cl, length(x) - 1, ncp = delta) / sqrt(length(x))
  }
  km_smry <- km_ple2(data.frame((x)^(1 / 3), det))
  KM_mean <- km_smry[1]
  KM_sd <- km_smry[3]
  value <- max(0, (KM_mean + k1 * KM_sd)^3)
  achiv_conf <- NA
  names(value) <- NULL
  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaWH_cenros -----
utl_gammaWH_cenros <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  # input x
  data <- suppressWarnings(NADA::cenros(x, !det)) # in cenrose fxn, TRUE = nd
  d.ROS <- data.frame(x = data$modeled, det = !(data$censored))
  d.ROS <- d.ROS[order(d.ROS$x), ]
  x_ros <- d.ROS$x

  if (is.numeric(length(x_ros))) {
    x <- x_ros
  }

  # calc utl with inputed x (x_ros)
  value <- EnvStats::tolIntGamma(x,
    ti.type = "upper",
    method = "exact",
    est.method = "mle",
    normal.approx.transform = "cube.root",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]

  achiv_conf <- NA
  names(value) <- NULL

  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaHW -----
utl_gammaHW <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  value <- EnvStats::tolIntGamma(x,
    ti.type = "upper",
    method = "exact",
    est.method = "mle",
    normal.approx.transform = "fourth.root",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]
  achiv_conf <- NA
  names(value) <- NULL
  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaHW_cenkm -----
utl_gammaHW_cenkm <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  if (length(x) > 30) {
    # Approximation method (Natrella 1963)
    aa <- 1 - ((qnorm(cl)^2) / (2 * (length(x) - 1)))
    bb <- (qnorm(cover)^2) - (qnorm(cl)^2) / length(x)
    k1 <- (qnorm(cover) + sqrt((qnorm(cover)^2) - aa * bb)) / aa
  } else {
    # non-central t-distribution method
    delta <- qnorm(cover) * sqrt(length(x))
    k1 <- qt(cl, length(x) - 1, ncp = delta) / sqrt(length(x))
  }
  km_smry <- km_ple2(data.frame((x)^(1 / 4), det))
  KM_mean <- km_smry[1]
  KM_sd <- km_smry[3]
  value <- max(0, (KM_mean + k1 * KM_sd)^4)
  achiv_conf <- NA
  names(value) <- NULL
  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaWH_cenros -----
utl_gammaHW_cenros <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  # input x
  data <- suppressWarnings(NADA::cenros(x, !det)) # in cenrose fxn, TRUE = nd
  d.ROS <- data.frame(x = data$modeled, det = !(data$censored))
  d.ROS <- d.ROS[order(d.ROS$x), ]
  x_ros <- d.ROS$x

  if (is.numeric(length(x_ros))) {
    x <- x_ros
  }

  # calc utl with inputed x (x_ros)
  value <- EnvStats::tolIntGamma(x,
    ti.type = "upper",
    method = "exact",
    est.method = "mle",
    normal.approx.transform = "fourth.root",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]

  achiv_conf <- NA
  names(value) <- NULL
  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaOPT -----
utl_gammaOPT <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  value <- EnvStats::tolIntGamma(x, # **gamma_UTL_optimize
    ti.type = "upper",
    method = "exact",
    est.method = "mle",
    normal.approx.transform = "kulkarni.powar",
    coverage = cl,
    conf.level = cl
  )$interval$limits[2]
  achiv_conf <- NA
  names(value) <- NULL
  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaOPT_cenkm -----
utl_gammaOPT_cenkm <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  transform_power <- EnvStats::tolIntGamma(x,
    ti.type = "upper",
    method = "exact",
    est.method = "mle",
    normal.approx.transform = "kulkarni.powar",
    coverage = cover,
    conf.level = cl,
  )$interval$normal.transform.power

  if (length(x) > 30) {
    # Approximation method (Natrella 1963)
    aa <- 1 - ((qnorm(cl)^2) / (2 * (length(x) - 1)))
    bb <- (qnorm(cover)^2) - (qnorm(cl)^2) / length(x)
    k1 <- (qnorm(cover) + sqrt((qnorm(cover)^2) - aa * bb)) / aa
  } else {
    # non-central t-distribution method
    delta <- qnorm(cover) * sqrt(length(x))
    k1 <- qt(cl, length(x) - 1, ncp = delta) / sqrt(length(x))
  }
  km_smry <- km_ple2(data.frame((x)^(transform_power), det))
  KM_mean <- km_smry[1]
  KM_sd <- km_smry[3]
  value <- max(0, (KM_mean + k1 * KM_sd)^(1 / transform_power))
  achiv_conf <- NA
  names(value) <- NULL

  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_gammaOPT_cenros -----
utl_gammaOPT_cenros <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  # input x
  data <- suppressWarnings(NADA::cenros(x, !det)) # in cenrose fxn, TRUE = nd
  d.ROS <- data.frame(x = data$modeled, det = !(data$censored))
  d.ROS <- d.ROS[order(d.ROS$x), ]
  x_ros <- d.ROS$x

  if (is.numeric(length(x_ros))) {
    x <- x_ros
  }
  # calc utl with inputed x (x_ros)
  value <- EnvStats::tolIntGamma(x,
    ti.type = "upper",
    method = "exact",
    est.method = "mle",
    normal.approx.transform = "kulkarni.powar",
    coverage = cover,
    conf.level = cl
  )$interval$limits[2]

  achiv_conf <- NA
  names(value) <- NULL

  utl <- list(value, achiv_conf)
  return(utl)
})

# utl_nonparam -----
utl_nonparam <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  if (length(x) < 2000) {
    a <- 0
    while (pbinom(length(x) - a, size = length(x), prob = cover) > 0.95) {
      a <- a + 1
    }
    rank_n <- (length(x) - a) + 1
  }
  if (length(x) >= 2000) {
    rank_n <- round(length(x) * cover + qnorm(cl) * sqrt(length(x) * cover * (1 - cover)) + 0.5, 0)
  }
  x <- x[order(x, decreasing = TRUE)]
  achiev_confid <- pf((rank_n * (1 - cover)) / ((length(x) - rank_n + 1) * cover),
    df1 = 2 * (length(x) - rank_n + 1),
    df2 = 2 * rank_n
  )
  value <- x[rank_n]
  return(list(
    value,
    achiev_confid
  ))
})




# utl_max -----
utl_max <- compiler::cmpfun(function(x, det, cl, cover, boots) {
  d <- data.frame(x, det)
  value <- max(d[d$det == TRUE, "x"])
  achiv_conf <- NA
  utl <- list(value, achiv_conf)
  return(utl)
})


# call_utl_method ---------------------------------------------------------------
# wrapper function to call utl method by method name and return utl, doesn't break if an individual utl method breaks

# # inputs:
# method = "ucl_t_cenkm"
# x = head(d_example$concentration, obv_num)
# det = head(d_example$detected, obv_num)
# conf_lvl = 0.95
# boots = NA
call_utl_method <- function(method, x, det, cl, cover, boots) {
  if (length(x) == length(det) & is.numeric(x)) {
    args <- list(x, det, cl, cover, boots)
    try(utl_in <- rlang::exec(method, !!!args), silent = T)
    if (exists("utl_in")) {
      names(utl_in) <- NULL
      return(utl_in)
    } else {
      return(NA)
    }
  } else {
    return(NA)
  }
}
